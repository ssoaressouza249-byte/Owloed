package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.GeminiPrefsRepository
import com.example.data.ScriptParser
import com.example.security.SecurityGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `app name and security guard match ADFLOW AI`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ADFLOW AI", appName)
    assertEquals("com.raylan.adflowai", context.packageName)
    val check = SecurityGuard.verify(context)
    assertTrue(check.isValid)
  }

  @Test
  fun `prefs default model is gemini-4-hydrogen`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = GeminiPrefsRepository(context)
    assertEquals("gemini-4-hydrogen", repo.getSelectedModel())
  }

  @Test
  fun `script parser extracts GANCHO OFERTA CTA scenes`() {
    val sampleAiReply =
      """
      TÍTULO: Mega Liquidação de Tênis
      DURAÇÃO_SUGERIDA: 30s
      SELO_OFERTA: 40% OFF HOJE

      [GANCHO] (0s-5s): Pare de pagar caro no seu próximo tênis!
      [OFERTA] (5s-20s): Modelos originais com até 40% de desconto na loja inteira.
      [CTA] (20s-30s): Clique no WhatsApp agora e garanta seu tamanho!
      """.trimIndent()

    val parsed = ScriptParser.parseIfMarketingScript(sampleAiReply, "divulgar loja de tenis")
    assertNotNull(parsed)
    assertEquals(3, parsed!!.scenes.size)
    assertEquals("GANCHO", parsed.scenes[0].tag)
    assertEquals("OFERTA", parsed.scenes[1].tag)
    assertEquals("CTA", parsed.scenes[2].tag)
    assertEquals("40% OFF HOJE", parsed.suggestedPromoBadge)
    assertEquals(30, parsed.suggestedDurationSec)
  }
}
