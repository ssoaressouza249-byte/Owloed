package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.AdFlowTab
import com.example.security.SecurityGuard
import com.example.security.TamperLockScreen
import com.example.ui.AdFlowViewModel
import com.example.ui.components.CyberBottomBarWithCredits
import com.example.ui.components.CyberHeaderBar
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.VideoStudioScreen
import com.example.ui.theme.AdFlowTheme
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonGold
import com.example.ui.theme.ObsidianBg

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
    )
    setContent {
      AdFlowTheme {
        val context = LocalContext.current
        val securityResult = remember { SecurityGuard.verify(context) }

        if (!securityResult.isValid) {
          TamperLockScreen(result = securityResult)
        } else {
          AdFlowRootApp()
        }
      }
    }
  }
}

@Composable
private fun AdFlowRootApp(viewModel: AdFlowViewModel = viewModel()) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors =
              listOf(
                Color(0xFF0E0B1D),
                ObsidianBg,
                Color(0xFF0A090E),
              )
          )
        )
  ) {
    // Subtle Cyber-Luxury ambient corner glow
    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(
            Brush.radialGradient(
              colors =
                listOf(
                  ElectricPurple.copy(alpha = 0.14f),
                  Color.Transparent,
                ),
            )
          )
    )

    Scaffold(
      containerColor = Color.Transparent,
      contentWindowInsets = WindowInsets(0, 0, 0, 0),
      topBar = {
        CyberHeaderBar(
          activeModel = state.selectedModel,
          hasApiKey = state.apiKey.isNotBlank(),
          modifier = Modifier.statusBarsPadding(),
        )
      },
      bottomBar = {
        CyberBottomBarWithCredits(
          activeTab = state.activeTab,
          onSelectTab = viewModel::selectTab,
        )
      },
    ) { innerPadding ->
      Column(
        modifier = Modifier.fillMaxSize().padding(innerPadding)
      ) {
        when (state.activeTab) {
          AdFlowTab.CHAT_SCRIPT ->
            ChatScreen(
              state = state,
              onToggleApiPanel = viewModel::toggleApiPanel,
              onSaveApiConfig = viewModel::updateApiKeyAndModel,
              onSelectModel = viewModel::selectModel,
              onSendMessage = viewModel::sendChatMessage,
              onTransformToVideo = viewModel::transformScriptToVideo,
            )

          AdFlowTab.VIDEO_STUDIO ->
            VideoStudioScreen(
              state = state,
              onAddPhotos = viewModel::addPhotos,
              onRemovePhoto = viewModel::removePhoto,
              onSelectDuration = viewModel::setDuration,
              onSelectQuality = viewModel::setQuality,
              onSelectStyle = viewModel::setVisualStyle,
              onUpdatePromoBadge = viewModel::setPromoBadge,
              onUpdateCaptionsText = viewModel::updateCaptionsFromText,
              onToggleTts = viewModel::setTtsEnabled,
              onTogglePreview = viewModel::togglePreviewPlayback,
              onScrubPreview = viewModel::scrubPreview,
              onExportMp4 = viewModel::exportVideoMp4,
              onDismissExport = viewModel::dismissExportState,
            )
        }
      }
    }
  }
}
