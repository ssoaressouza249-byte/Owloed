package com.example.model

import android.net.Uri
import java.util.UUID

enum class AdFlowTab {
  CHAT_SCRIPT,
  VIDEO_STUDIO,
}

enum class MessageRole {
  USER,
  ASSISTANT,
}

data class AdScene(
  val id: String = UUID.randomUUID().toString(),
  val tag: String,
  val caption: String,
)

data class VideoScriptPayload(
  val title: String,
  val scenes: List<AdScene>,
  val fullNarration: String,
  val suggestedPromoBadge: String,
  val suggestedDurationSec: Int,
)

data class ChatMessage(
  val id: String = UUID.randomUUID().toString(),
  val role: MessageRole,
  val text: String,
  val timestampMs: Long = System.currentTimeMillis(),
  val scriptPayload: VideoScriptPayload? = null,
  val isError: Boolean = false,
)

enum class VideoDurationOption(val seconds: Int, val label: String) {
  SEC_15(15, "15s"),
  SEC_30(30, "30s"),
  SEC_60(60, "60s"),
}

enum class VideoQualityOption(
  val width: Int,
  val height: Int,
  val shortLabel: String,
  val fullLabel: String,
) {
  FHD_1080P(1080, 1920, "1080p", "1080p Full HD (1080×1920)"),
  ULTRA_2K(1440, 2560, "2K Ultra", "2K Ultra (1440×2560)"),
}

enum class VisualStyleOption(val title: String, val subtitle: String) {
  NEON_GAMER("Neon Gamer", "Roxo Elétrico & HUD Cyber"),
  FLASH_OFFER("Oferta Relâmpago", "Dourado Neon & Urgência"),
  MINIMAL_LUXURY("Luxo Minimalista", "Obsidiana & Moldura Ouro"),
}

sealed interface ExportState {
  data object Idle : ExportState

  data class Rendering(
    val progress: Float,
    val stageLabel: String,
    val targetResolution: String,
  ) : ExportState

  data class Success(
    val videoUri: Uri,
    val displayPath: String,
    val width: Int,
    val height: Int,
    val usedFallback1080p: Boolean,
    val hasAudioTrack: Boolean,
  ) : ExportState

  data class Error(val message: String) : ExportState
}
