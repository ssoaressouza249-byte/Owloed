package com.example.video

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.model.AdScene
import com.example.model.VisualStyleOption
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object AdFrameRenderer {

  private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
  private val photoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
  private val overlayPaint = Paint(Paint.ANTI_ALIAS_FLAG)
  private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG)
  private val badgeFillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
  private val badgeGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
  private val captionBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
  private val captionAccentPaint = Paint(Paint.ANTI_ALIAS_FLAG)
  private val tagPillPaint = Paint(Paint.ANTI_ALIAS_FLAG)

  private val badgeTextPaint =
    TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
      typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
      textAlign = Paint.Align.CENTER
    }

  private val tagTextPaint =
    TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
      typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
      textAlign = Paint.Align.LEFT
    }

  private val captionTextPaint =
    TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
      typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

  private val watermarkPaint =
    TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
      typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
      textAlign = Paint.Align.LEFT
    }

  fun drawFrame(
    canvas: Canvas,
    width: Int,
    height: Int,
    photos: List<Bitmap>,
    scenes: List<AdScene>,
    promoBadge: String,
    style: VisualStyleOption,
    elapsedSec: Float,
    totalDurationSec: Float,
  ) {
    val w = width.toFloat().coerceAtLeast(1f)
    val h = height.toFloat().coerceAtLeast(1f)
    val safeTotal = totalDurationSec.coerceAtLeast(1f)
    val progress = (elapsedSec / safeTotal).coerceIn(0f, 1f)

    // 1. Deep Obsidian base
    bgPaint.shader = null
    bgPaint.color = Color.parseColor("#07080C")
    canvas.drawRect(0f, 0f, w, h, bgPaint)

    // 2. Photos with Ken Burns cinematic zoom + crossfade, or studio cyber backdrop
    if (photos.isNotEmpty()) {
      drawKenBurnsPhotos(canvas, w, h, photos, progress)
    } else {
      drawEmptyStudioBackdrop(canvas, w, h, style, elapsedSec)
    }

    // 3. Cinematic style vignette & frames
    drawStyleOverlay(canvas, w, h, style, elapsedSec)

    // 4. Top Brand Micro-Watermark ("ADFLOW AI STUDIO")
    val scaleFactor = w / 1080f
    watermarkPaint.color = Color.argb(185, 248, 250, 252)
    watermarkPaint.textSize = 26f * scaleFactor
    canvas.drawText("ADFLOW AI", 48f * scaleFactor, 76f * scaleFactor, watermarkPaint)

    // 5. Pulsing Offer / Price Badge
    if (promoBadge.isNotBlank()) {
      drawPulsingPromoBadge(canvas, w, h, promoBadge.trim(), style, elapsedSec, scaleFactor)
    }

    // 6. Synchronized Dynamic Reels/TikTok Captions
    val activeScene = resolveActiveScene(scenes, progress)
    if (activeScene != null) {
      drawDynamicCaption(canvas, w, h, activeScene, style, elapsedSec, scaleFactor)
    }
  }

  private fun drawKenBurnsPhotos(
    canvas: Canvas,
    w: Float,
    h: Float,
    photos: List<Bitmap>,
    globalProgress: Float,
  ) {
    val count = photos.size
    if (count == 1) {
      drawSingleKenBurnsBitmap(canvas, w, h, photos[0], globalProgress, zoomIn = true, alpha = 255)
      return
    }

    val scaledPos = globalProgress * count
    val currentIndex = scaledPos.toInt().coerceIn(0, count - 1)
    val localProgress = (scaledPos - currentIndex).coerceIn(0f, 1f)

    // Draw current photo
    drawSingleKenBurnsBitmap(
      canvas = canvas,
      w = w,
      h = h,
      bitmap = photos[currentIndex],
      localProgress = localProgress,
      zoomIn = currentIndex % 2 == 0,
      alpha = 255,
    )

    // Smooth crossfade to next photo during the last 18% of each slide
    if (localProgress > 0.82f && currentIndex < count - 1) {
      val fadeAlpha = (((localProgress - 0.82f) / 0.18f) * 255f).toInt().coerceIn(0, 255)
      drawSingleKenBurnsBitmap(
        canvas = canvas,
        w = w,
        h = h,
        bitmap = photos[currentIndex + 1],
        localProgress = 0f,
        zoomIn = (currentIndex + 1) % 2 == 0,
        alpha = fadeAlpha,
      )
    }
  }

  private fun drawSingleKenBurnsBitmap(
    canvas: Canvas,
    w: Float,
    h: Float,
    bitmap: Bitmap,
    localProgress: Float,
    zoomIn: Boolean,
    alpha: Int,
  ) {
    if (bitmap.isRecycled || bitmap.width <= 0 || bitmap.height <= 0) return

    val bw = bitmap.width.toFloat()
    val bh = bitmap.height.toFloat()

    val baseScale = max(w / bw, h / bh)
    val zoomFactor =
      if (zoomIn) {
        1.02f + 0.14f * localProgress
      } else {
        1.16f - 0.14f * localProgress
      }
    val finalScale = baseScale * zoomFactor

    val drawnW = bw * finalScale
    val drawnH = bh * finalScale
    val maxPanX = ((drawnW - w) * 0.35f).coerceAtLeast(0f)
    val maxPanY = ((drawnH - h) * 0.25f).coerceAtLeast(0f)
    val panSign = if (zoomIn) 1f else -1f
    val dx = (w - drawnW) / 2f + panSign * maxPanX * (localProgress - 0.5f)
    val dy = (h - drawnH) / 2f - panSign * maxPanY * (localProgress - 0.5f)

    val matrix = Matrix()
    matrix.postScale(finalScale, finalScale)
    matrix.postTranslate(dx, dy)

    photoPaint.alpha = alpha
    canvas.drawBitmap(bitmap, matrix, photoPaint)
  }

  private fun drawEmptyStudioBackdrop(
    canvas: Canvas,
    w: Float,
    h: Float,
    style: VisualStyleOption,
    elapsedSec: Float,
  ) {
    val primaryColor =
      when (style) {
        VisualStyleOption.NEON_GAMER -> Color.parseColor("#7C3AED")
        VisualStyleOption.FLASH_OFFER -> Color.parseColor("#F59E0B")
        VisualStyleOption.MINIMAL_LUXURY -> Color.parseColor("#92400E")
      }
    val secondaryColor =
      when (style) {
        VisualStyleOption.NEON_GAMER -> Color.parseColor("#22D3EE")
        VisualStyleOption.FLASH_OFFER -> Color.parseColor("#EF4444")
        VisualStyleOption.MINIMAL_LUXURY -> Color.parseColor("#F59E0B")
      }

    val pulse = (0.5f + 0.5f * sin(elapsedSec * 2.2f)).toFloat()
    bgPaint.shader =
      RadialGradient(
        w * (0.35f + 0.3f * pulse),
        h * 0.38f,
        w * 0.85f,
        intArrayOf(Color.argb(120, Color.red(primaryColor), Color.green(primaryColor), Color.blue(primaryColor)), Color.parseColor("#07080C")),
        floatArrayOf(0f, 1f),
        Shader.TileMode.CLAMP,
      )
    canvas.drawRect(0f, 0f, w, h, bgPaint)

    bgPaint.shader =
      RadialGradient(
        w * (0.65f - 0.25f * pulse),
        h * 0.68f,
        w * 0.7f,
        intArrayOf(Color.argb(90, Color.red(secondaryColor), Color.green(secondaryColor), Color.blue(secondaryColor)), Color.TRANSPARENT),
        floatArrayOf(0f, 1f),
        Shader.TileMode.CLAMP,
      )
    canvas.drawRect(0f, 0f, w, h, bgPaint)
    bgPaint.shader = null
  }

  private fun drawStyleOverlay(
    canvas: Canvas,
    w: Float,
    h: Float,
    style: VisualStyleOption,
    elapsedSec: Float,
  ) {
    val scaleFactor = w / 1080f

    // Bottom readability gradient (essential for Reels/TikTok caption legibility)
    overlayPaint.shader =
      LinearGradient(
        0f,
        h * 0.45f,
        0f,
        h,
        intArrayOf(Color.TRANSPARENT, Color.argb(165, 7, 8, 12), Color.argb(235, 7, 8, 12)),
        floatArrayOf(0f, 0.55f, 1f),
        Shader.TileMode.CLAMP,
      )
    canvas.drawRect(0f, h * 0.45f, w, h, overlayPaint)

    // Top subtle readability gradient
    overlayPaint.shader =
      LinearGradient(
        0f,
        0f,
        0f,
        h * 0.22f,
        intArrayOf(Color.argb(190, 7, 8, 12), Color.TRANSPARENT),
        floatArrayOf(0f, 1f),
        Shader.TileMode.CLAMP,
      )
    canvas.drawRect(0f, 0f, w, h * 0.22f, overlayPaint)
    overlayPaint.shader = null

    val margin = 32f * scaleFactor
    val cornerLen = 68f * scaleFactor
    borderPaint.style = Paint.Style.STROKE

    when (style) {
      VisualStyleOption.NEON_GAMER -> {
        // Purple + Cyan cyber HUD corner brackets
        borderPaint.strokeWidth = 6f * scaleFactor
        borderPaint.color = Color.parseColor("#7C3AED")
        canvas.drawRect(margin, margin, w - margin, h - margin, borderPaint.apply { alpha = 110 })

        borderPaint.alpha = 255
        borderPaint.strokeWidth = 10f * scaleFactor
        borderPaint.color = Color.parseColor("#22D3EE")
        // Top-left bracket
        canvas.drawLine(margin, margin, margin + cornerLen, margin, borderPaint)
        canvas.drawLine(margin, margin, margin, margin + cornerLen, borderPaint)
        // Bottom-right bracket
        canvas.drawLine(w - margin, h - margin, w - margin - cornerLen, h - margin, borderPaint)
        canvas.drawLine(w - margin, h - margin, w - margin, h - margin - cornerLen, borderPaint)

        // Subtle cyber scanlines
        overlayPaint.color = Color.argb(18, 167, 139, 250)
        overlayPaint.strokeWidth = 2f * scaleFactor
        var y = 0f
        val step = 18f * scaleFactor
        while (y < h) {
          canvas.drawLine(0f, y, w, y, overlayPaint)
          y += step
        }
      }

      VisualStyleOption.FLASH_OFFER -> {
        val flashPulse = (0.55f + 0.45f * sin(elapsedSec * 7f)).toFloat()
        borderPaint.strokeWidth = 12f * scaleFactor
        borderPaint.color = Color.parseColor("#F59E0B")
        borderPaint.alpha = (160 + 95 * flashPulse).toInt().coerceIn(0, 255)
        canvas.drawRoundRect(
          RectF(margin, margin, w - margin, h - margin),
          28f * scaleFactor,
          28f * scaleFactor,
          borderPaint,
        )

        borderPaint.strokeWidth = 4f * scaleFactor
        borderPaint.color = Color.parseColor("#EF4444")
        borderPaint.alpha = (180 * flashPulse).toInt().coerceIn(0, 255)
        canvas.drawRoundRect(
          RectF(margin + 12f * scaleFactor, margin + 12f * scaleFactor, w - margin - 12f * scaleFactor, h - margin - 12f * scaleFactor),
          22f * scaleFactor,
          22f * scaleFactor,
          borderPaint,
        )
      }

      VisualStyleOption.MINIMAL_LUXURY -> {
        borderPaint.strokeWidth = 3f * scaleFactor
        borderPaint.color = Color.parseColor("#F59E0B")
        borderPaint.alpha = 185
        val luxMargin = 42f * scaleFactor
        canvas.drawRect(luxMargin, luxMargin, w - luxMargin, h - luxMargin, borderPaint)

        borderPaint.strokeWidth = 1.5f * scaleFactor
        borderPaint.color = Color.parseColor("#FDE68A")
        borderPaint.alpha = 110
        canvas.drawRect(
          luxMargin + 10f * scaleFactor,
          luxMargin + 10f * scaleFactor,
          w - luxMargin - 10f * scaleFactor,
          h - luxMargin - 10f * scaleFactor,
          borderPaint,
        )
      }
    }
  }

  private fun drawPulsingPromoBadge(
    canvas: Canvas,
    w: Float,
    h: Float,
    badgeText: String,
    style: VisualStyleOption,
    elapsedSec: Float,
    scaleFactor: Float,
  ) {
    val pulse = 1.0f + 0.055f * sin(elapsedSec * 2.0 * PI * 1.4).toFloat()
    val textUpper = badgeText.uppercase()
    badgeTextPaint.textSize = 42f * scaleFactor
    val measuredTextW = badgeTextPaint.measureText(textUpper)
    val pillW = min(w * 0.72f, measuredTextW + 86f * scaleFactor)
    val pillH = 92f * scaleFactor

    val centerX = w - 56f * scaleFactor - pillW / 2f
    val centerY = 175f * scaleFactor

    canvas.save()
    canvas.scale(pulse, pulse, centerX, centerY)

    val rect =
      RectF(
        centerX - pillW / 2f,
        centerY - pillH / 2f,
        centerX + pillW / 2f,
        centerY + pillH / 2f,
      )

    // Soft outer glow
    badgeGlowPaint.color =
      when (style) {
        VisualStyleOption.NEON_GAMER -> Color.argb(115, 124, 58, 237)
        VisualStyleOption.FLASH_OFFER -> Color.argb(135, 245, 158, 11)
        VisualStyleOption.MINIMAL_LUXURY -> Color.argb(95, 245, 158, 11)
      }
    val glowRect =
      RectF(
        rect.left - 10f * scaleFactor,
        rect.top - 10f * scaleFactor,
        rect.right + 10f * scaleFactor,
        rect.bottom + 10f * scaleFactor,
      )
    canvas.drawRoundRect(glowRect, 28f * scaleFactor, 28f * scaleFactor, badgeGlowPaint)

    // Badge gradient fill
    val colors =
      when (style) {
        VisualStyleOption.NEON_GAMER ->
          intArrayOf(Color.parseColor("#7C3AED"), Color.parseColor("#2563EB"))
        VisualStyleOption.FLASH_OFFER ->
          intArrayOf(Color.parseColor("#F59E0B"), Color.parseColor("#DC2626"))
        VisualStyleOption.MINIMAL_LUXURY ->
          intArrayOf(Color.parseColor("#11131D"), Color.parseColor("#1E1B16"))
      }
    badgeFillPaint.shader =
      LinearGradient(rect.left, rect.top, rect.right, rect.bottom, colors, null, Shader.TileMode.CLAMP)
    canvas.drawRoundRect(rect, 24f * scaleFactor, 24f * scaleFactor, badgeFillPaint)
    badgeFillPaint.shader = null

    if (style == VisualStyleOption.MINIMAL_LUXURY) {
      borderPaint.style = Paint.Style.STROKE
      borderPaint.strokeWidth = 3f * scaleFactor
      borderPaint.color = Color.parseColor("#F59E0B")
      borderPaint.alpha = 255
      canvas.drawRoundRect(rect, 24f * scaleFactor, 24f * scaleFactor, borderPaint)
      badgeTextPaint.color = Color.parseColor("#FBBF24")
    } else {
      badgeTextPaint.color = Color.WHITE
    }

    val fontMetrics = badgeTextPaint.fontMetrics
    val textY = centerY - (fontMetrics.ascent + fontMetrics.descent) / 2f
    canvas.drawText(textUpper, centerX, textY, badgeTextPaint)
    canvas.restore()
  }

  private fun resolveActiveScene(scenes: List<AdScene>, progress: Float): AdScene? {
    if (scenes.isEmpty()) return null
    val index = (progress * scenes.size).toInt().coerceIn(0, scenes.lastIndex)
    return scenes[index]
  }

  @Suppress("DEPRECATION")
  private fun drawDynamicCaption(
    canvas: Canvas,
    w: Float,
    h: Float,
    scene: AdScene,
    style: VisualStyleOption,
    elapsedSec: Float,
    scaleFactor: Float,
  ) {
    val boxMaxW = (w * 0.84f).toInt().coerceAtLeast(100)
    val captionStr = scene.caption.trim()
    if (captionStr.isEmpty()) return

    captionTextPaint.textSize = 54f * scaleFactor
    captionTextPaint.color =
      when (style) {
        VisualStyleOption.NEON_GAMER -> Color.WHITE
        VisualStyleOption.FLASH_OFFER -> Color.parseColor("#FEF08A")
        VisualStyleOption.MINIMAL_LUXURY -> Color.parseColor("#F8FAFC")
      }
    captionTextPaint.setShadowLayer(
      12f * scaleFactor,
      0f,
      4f * scaleFactor,
      Color.argb(210, 0, 0, 0),
    )

    val staticLayout =
      StaticLayout.Builder.obtain(captionStr, 0, captionStr.length, captionTextPaint, boxMaxW)
        .setAlignment(Layout.Alignment.ALIGN_CENTER)
        .setLineSpacing(6f * scaleFactor, 1.08f)
        .setMaxLines(4)
        .build()

    val padX = 36f * scaleFactor
    val padY = 26f * scaleFactor
    val contentH = staticLayout.height.toFloat()
    val boxW = boxMaxW + padX * 2f
    val boxLeft = (w - boxW) / 2f
    val boxBottom = h - 145f * scaleFactor
    val boxTop = boxBottom - contentH - padY * 2f

    // Scene Tag Pill above the caption (GANCHO / OFERTA / CTA)
    val tagLabel = scene.tag.uppercase().ifBlank { "DESTAQUE" }
    tagTextPaint.textSize = 26f * scaleFactor
    val tagTextW = tagTextPaint.measureText(tagLabel)
    val tagPillW = tagTextW + 38f * scaleFactor
    val tagPillH = 44f * scaleFactor
    val tagLeft = (w - tagPillW) / 2f
    val tagTop = boxTop - tagPillH - 14f * scaleFactor

    tagPillPaint.color =
      when (style) {
        VisualStyleOption.NEON_GAMER -> Color.parseColor("#7C3AED")
        VisualStyleOption.FLASH_OFFER -> Color.parseColor("#F59E0B")
        VisualStyleOption.MINIMAL_LUXURY -> Color.parseColor("#D97706")
      }
    canvas.drawRoundRect(
      RectF(tagLeft, tagTop, tagLeft + tagPillW, tagTop + tagPillH),
      14f * scaleFactor,
      14f * scaleFactor,
      tagPillPaint,
    )
    tagTextPaint.color =
      if (style == VisualStyleOption.FLASH_OFFER) 0xFF1A1000.toInt() else Color.WHITE
    val tagFm = tagTextPaint.fontMetrics
    val tagTextY = tagTop + tagPillH / 2f - (tagFm.ascent + tagFm.descent) / 2f
    canvas.drawText(tagLabel, tagLeft + 19f * scaleFactor, tagTextY, tagTextPaint)

    // Caption translucent cyber-luxury card
    val boxRect = RectF(boxLeft, boxTop, boxLeft + boxW, boxBottom)
    captionBoxPaint.color =
      when (style) {
        VisualStyleOption.NEON_GAMER -> Color.argb(205, 14, 12, 32)
        VisualStyleOption.FLASH_OFFER -> Color.argb(215, 18, 10, 8)
        VisualStyleOption.MINIMAL_LUXURY -> Color.argb(200, 7, 8, 12)
      }
    canvas.drawRoundRect(boxRect, 28f * scaleFactor, 28f * scaleFactor, captionBoxPaint)

    // Animated border accent around caption box
    val accentPulse = (0.75f + 0.25f * sin(elapsedSec * 4.5f)).toFloat()
    captionAccentPaint.style = Paint.Style.STROKE
    captionAccentPaint.strokeWidth = 4f * scaleFactor
    captionAccentPaint.color =
      when (style) {
        VisualStyleOption.NEON_GAMER -> Color.parseColor("#22D3EE")
        VisualStyleOption.FLASH_OFFER -> Color.parseColor("#F59E0B")
        VisualStyleOption.MINIMAL_LUXURY -> Color.parseColor("#F59E0B")
      }
    captionAccentPaint.alpha = (180 + 75 * accentPulse).toInt().coerceIn(0, 255)
    canvas.drawRoundRect(boxRect, 28f * scaleFactor, 28f * scaleFactor, captionAccentPaint)

    canvas.save()
    canvas.translate(boxLeft + padX, boxTop + padY)
    staticLayout.draw(canvas)
    canvas.restore()
  }
}
