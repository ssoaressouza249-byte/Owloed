package com.example.video

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.model.AdScene
import com.example.model.VideoQualityOption
import com.example.model.VisualStyleOption
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

data class VideoExportOutput(
  val uri: Uri,
  val displayPath: String,
  val width: Int,
  val height: Int,
  val usedFallback1080p: Boolean,
  val hasAudioTrack: Boolean,
)

class AdVideoExporter(
  private val context: Context,
  private val ttsManager: TtsNarrationManager,
) {

  suspend fun exportVideo(
    photoUris: List<Uri>,
    scenes: List<AdScene>,
    narrationText: String,
    promoBadge: String,
    durationSec: Int,
    requestedQuality: VideoQualityOption,
    style: VisualStyleOption,
    enableTts: Boolean,
    onProgress: (progress: Float, stageLabel: String, targetResLabel: String) -> Unit,
  ): Result<VideoExportOutput> =
    withContext(Dispatchers.IO) {
      runCatching {
        val safeDurationSec = durationSec.coerceIn(15, 60)

        // 1. Resolve target resolution with strict 2K cap and safe 1080p fallback
        var targetW = min(requestedQuality.width, MAX_WIDTH_2K)
        var targetH = min(requestedQuality.height, MAX_HEIGHT_2K)
        var usedFallback = false

        if (requestedQuality == VideoQualityOption.ULTRA_2K && !isAvcSizeSupported(targetW, targetH)) {
          targetW = VideoQualityOption.FHD_1080P.width
          targetH = VideoQualityOption.FHD_1080P.height
          usedFallback = true
        }

        val initialResLabel = "${targetW}×${targetH}"
        onProgress(0.03f, "Preparando mídia e áudio...", initialResLabel)

        // 2. Decode and pre-scale selected photos safely to avoid OOM
        val bitmaps = loadScaledBitmaps(photoUris, targetW, targetH)
        val tempDir = File(context.cacheDir, "adflow_export").apply { mkdirs() }
        val tempMp4 = File(tempDir, "adflow_tmp_${System.currentTimeMillis()}.mp4")
        val tempWav = File(tempDir, "adflow_tts_${System.currentTimeMillis()}.wav")

        try {
          // 3. Optional PT-BR TTS WAV -> AAC pre-encoding
          var encodedAudio: EncodedAudioTrack? = null
          if (enableTts && narrationText.isNotBlank()) {
            onProgress(0.08f, "Sintetizando narração PT-BR...", initialResLabel)
            val wavFile = ttsManager.synthesizeToWavFile(narrationText, tempWav)
            if (wavFile != null) {
              encodedAudio =
                runCatching { encodeWavToAac(wavFile, safeDurationSec) }.getOrNull()
            }
          }

          // 4. Encode video with automatic fallback chain:
          //    Requested (2K or 1080p) -> 1080p Surface -> 1080p YUV420 -> 720p YUV420
          val attemptSpecs = buildAttemptChain(targetW, targetH, usedFallback)
          var completedWidth = targetW
          var completedHeight = targetH
          var finalUsedFallback = usedFallback
          var renderedOk = false
          var lastError: Throwable? = null

          for (spec in attemptSpecs) {
            ensureActive()
            val resLabel = "${spec.width}×${spec.height}"
            val result =
              runCatching {
                if (tempMp4.exists()) tempMp4.delete()
                if (spec.useSurface) {
                  renderWithSurfaceEncoder(
                    outputFile = tempMp4,
                    width = spec.width,
                    height = spec.height,
                    photos = bitmaps,
                    scenes = scenes,
                    promoBadge = promoBadge,
                    style = style,
                    durationSec = safeDurationSec,
                    audioTrack = encodedAudio,
                  ) { p ->
                    onProgress(0.12f + p * 0.80f, "Renderizando quadros ($resLabel)...", resLabel)
                  }
                } else {
                  renderWithYuvBufferEncoder(
                    outputFile = tempMp4,
                    width = spec.width,
                    height = spec.height,
                    photos = bitmaps,
                    scenes = scenes,
                    promoBadge = promoBadge,
                    style = style,
                    durationSec = safeDurationSec,
                    audioTrack = encodedAudio,
                  ) { p ->
                    onProgress(0.12f + p * 0.80f, "Renderizando compatibilidade ($resLabel)...", resLabel)
                  }
                }
              }

            if (result.isSuccess && tempMp4.exists() && tempMp4.length() > 1024L) {
              completedWidth = spec.width
              completedHeight = spec.height
              finalUsedFallback = spec.isFallbackFrom2K || usedFallback
              renderedOk = true
              break
            } else {
              lastError = result.exceptionOrNull()
            }
          }

          if (!renderedOk) {
            throw IllegalStateException(
              lastError?.message ?: "Não foi possível inicializar o MediaCodec neste dispositivo."
            )
          }

          onProgress(0.95f, "Salvando em Movies/AdFlowAI...", "${completedWidth}×${completedHeight}")

          // 5. Publish to Movies/AdFlowAI via MediaStore (API 29+) or public/app Movies dir
          val (savedUri, displayPath) = saveVideoToMovies(tempMp4)
          onProgress(1f, "Concluído!", "${completedWidth}×${completedHeight}")

          VideoExportOutput(
            uri = savedUri,
            displayPath = displayPath,
            width = completedWidth,
            height = completedHeight,
            usedFallback1080p = finalUsedFallback,
            hasAudioTrack = encodedAudio != null,
          )
        } finally {
          bitmaps.forEach { bmp -> runCatching { if (!bmp.isRecycled) bmp.recycle() } }
          runCatching { tempMp4.delete() }
          runCatching { tempWav.delete() }
        }
      }
    }

  private data class RenderSpec(
    val width: Int,
    val height: Int,
    val useSurface: Boolean,
    val isFallbackFrom2K: Boolean,
  )

  private fun buildAttemptChain(
    targetW: Int,
    targetH: Int,
    alreadyFallback: Boolean,
  ): List<RenderSpec> {
    val list = mutableListOf<RenderSpec>()
    if (targetW >= 1440) {
      list.add(RenderSpec(1440, 2560, useSurface = true, isFallbackFrom2K = false))
      list.add(RenderSpec(1080, 1920, useSurface = true, isFallbackFrom2K = true))
      list.add(RenderSpec(1080, 1920, useSurface = false, isFallbackFrom2K = true))
      list.add(RenderSpec(720, 1280, useSurface = false, isFallbackFrom2K = true))
    } else {
      list.add(RenderSpec(1080, 1920, useSurface = true, isFallbackFrom2K = alreadyFallback))
      list.add(RenderSpec(1080, 1920, useSurface = false, isFallbackFrom2K = alreadyFallback))
      list.add(RenderSpec(720, 1280, useSurface = false, isFallbackFrom2K = true))
    }
    return list
  }

  private fun isAvcSizeSupported(width: Int, height: Int): Boolean {
    return runCatching {
        val list = MediaCodecList(MediaCodecList.REGULAR_CODECS)
        list.codecInfos.any { info ->
          if (!info.isEncoder) return@any false
          if (!info.supportedTypes.any { it.equals(MediaFormat.MIMETYPE_VIDEO_AVC, ignoreCase = true) }) {
            return@any false
          }
          val caps = info.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC)
          caps.videoCapabilities?.isSizeSupported(width, height) == true
        }
      }
      .getOrDefault(false)
  }

  private fun loadScaledBitmaps(uris: List<Uri>, targetW: Int, targetH: Int): List<Bitmap> {
    val result = mutableListOf<Bitmap>()
    for (uri in uris) {
      runCatching {
        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { stream ->
          BitmapFactory.decodeStream(stream, null, boundsOpts)
        }
        val srcW = boundsOpts.outWidth.coerceAtLeast(1)
        val srcH = boundsOpts.outHeight.coerceAtLeast(1)
        var sampleSize = 1
        while (srcW / sampleSize > targetW * 1.5f || srcH / sampleSize > targetH * 1.5f) {
          sampleSize *= 2
        }

        val decodeOpts =
          BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
          }
        val decoded =
          context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, decodeOpts)
          }
        if (decoded != null) {
          result.add(decoded)
        }
      }
    }
    return result
  }

  private fun renderWithSurfaceEncoder(
    outputFile: File,
    width: Int,
    height: Int,
    photos: List<Bitmap>,
    scenes: List<AdScene>,
    promoBadge: String,
    style: VisualStyleOption,
    durationSec: Int,
    audioTrack: EncodedAudioTrack?,
    onFrameProgress: (Float) -> Unit,
  ) {
    val totalFrames = durationSec * FPS
    val frameDurationUs = 1_000_000L / FPS
    val bitRate = if (width >= 1440) 14_000_000 else 8_000_000

    val format =
      MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
        setInteger(
          MediaFormat.KEY_COLOR_FORMAT,
          MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface,
        )
        setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
        setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
        setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
      }

    var encoder: MediaCodec? = null
    var inputSurface: android.view.Surface? = null
    var muxer: MediaMuxer? = null

    try {
      encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
      encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
      inputSurface = encoder.createInputSurface()
      encoder.start()

      muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
      var muxerStarted = false
      var videoTrackIndex = -1
      var audioTrackIndex = -1
      var audioWritten = false
      var outputFrameIdx = 0L

      val bufferInfo = MediaCodec.BufferInfo()

      fun drainEncoder(endOfStream: Boolean) {
        if (endOfStream) {
          encoder.signalEndOfInputStream()
        }
        var eosTryLaterCount = 0
        while (true) {
          val outIndex = encoder.dequeueOutputBuffer(bufferInfo, 10_000L)
          if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
            if (!endOfStream) break
            eosTryLaterCount++
            if (eosTryLaterCount > 250) break
          } else if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
            if (!muxerStarted) {
              videoTrackIndex = muxer.addTrack(encoder.outputFormat)
              if (audioTrack != null) {
                audioTrackIndex = muxer.addTrack(audioTrack.format)
              }
              muxer.start()
              muxerStarted = true
              if (audioTrack != null && !audioWritten && audioTrackIndex >= 0) {
                writeEncodedAudio(muxer, audioTrackIndex, audioTrack)
                audioWritten = true
              }
            }
          } else if (outIndex >= 0) {
            val encodedData = encoder.getOutputBuffer(outIndex)
            if (encodedData != null && bufferInfo.size > 0) {
              if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                bufferInfo.size = 0
              } else if (muxerStarted) {
                encodedData.position(bufferInfo.offset)
                encodedData.limit(bufferInfo.offset + bufferInfo.size)
                bufferInfo.presentationTimeUs = outputFrameIdx * frameDurationUs
                outputFrameIdx++
                muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
              }
            }
            encoder.releaseOutputBuffer(outIndex, false)
            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
              break
            }
          }
        }
      }

      for (frameIdx in 0 until totalFrames) {
        val elapsedSec = frameIdx.toFloat() / FPS.toFloat()
        val canvas = inputSurface.lockCanvas(null)
        try {
          AdFrameRenderer.drawFrame(
            canvas = canvas,
            width = width,
            height = height,
            photos = photos,
            scenes = scenes,
            promoBadge = promoBadge,
            style = style,
            elapsedSec = elapsedSec,
            totalDurationSec = durationSec.toFloat(),
          )
        } finally {
          inputSurface.unlockCanvasAndPost(canvas)
        }
        drainEncoder(endOfStream = false)
        if (frameIdx % 6 == 0 || frameIdx == totalFrames - 1) {
          onFrameProgress((frameIdx + 1).toFloat() / totalFrames.toFloat())
        }
      }

      drainEncoder(endOfStream = true)
      if (muxerStarted) {
        muxer.stop()
      }
    } finally {
      runCatching { inputSurface?.release() }
      runCatching { encoder?.stop() }
      runCatching { encoder?.release() }
      runCatching { muxer?.release() }
    }
  }

  private fun renderWithYuvBufferEncoder(
    outputFile: File,
    width: Int,
    height: Int,
    photos: List<Bitmap>,
    scenes: List<AdScene>,
    promoBadge: String,
    style: VisualStyleOption,
    durationSec: Int,
    audioTrack: EncodedAudioTrack?,
    onFrameProgress: (Float) -> Unit,
  ) {
    val totalFrames = durationSec * FPS
    val frameDurationUs = 1_000_000L / FPS
    val bitRate = if (width >= 1440) 14_000_000 else 8_000_000

    var encoder: MediaCodec? = null
    var muxer: MediaMuxer? = null
    val frameBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val frameCanvas = android.graphics.Canvas(frameBitmap)
    val argbPixels = IntArray(width * height)

    try {
      encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
      val caps = encoder.codecInfo.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC)
      val colorFormat = selectYuvColorFormat(caps.colorFormats)
      val isSemiPlanar =
        colorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar ||
          colorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420PackedSemiPlanar

      val format =
        MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
          setInteger(MediaFormat.KEY_COLOR_FORMAT, colorFormat)
          setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
          setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
          setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }

      encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
      encoder.start()

      muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
      var muxerStarted = false
      var videoTrackIndex = -1
      var audioTrackIndex = -1
      var audioWritten = false

      val bufferInfo = MediaCodec.BufferInfo()
      val yuvBytes = ByteArray(width * height * 3 / 2)

      fun drainOutput(endOfStream: Boolean) {
        while (true) {
          val outIndex = encoder.dequeueOutputBuffer(bufferInfo, if (endOfStream) 10_000L else 0L)
          if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
            if (!endOfStream) break
          } else if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
            if (!muxerStarted) {
              videoTrackIndex = muxer.addTrack(encoder.outputFormat)
              if (audioTrack != null) {
                audioTrackIndex = muxer.addTrack(audioTrack.format)
              }
              muxer.start()
              muxerStarted = true
              if (audioTrack != null && !audioWritten && audioTrackIndex >= 0) {
                writeEncodedAudio(muxer, audioTrackIndex, audioTrack)
                audioWritten = true
              }
            }
          } else if (outIndex >= 0) {
            val encodedData = encoder.getOutputBuffer(outIndex)
            if (encodedData != null && bufferInfo.size > 0) {
              if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                bufferInfo.size = 0
              } else if (muxerStarted) {
                encodedData.position(bufferInfo.offset)
                encodedData.limit(bufferInfo.offset + bufferInfo.size)
                muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
              }
            }
            encoder.releaseOutputBuffer(outIndex, false)
            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
              break
            }
          }
        }
      }

      for (frameIdx in 0 until totalFrames) {
        val elapsedSec = frameIdx.toFloat() / FPS.toFloat()
        AdFrameRenderer.drawFrame(
          canvas = frameCanvas,
          width = width,
          height = height,
          photos = photos,
          scenes = scenes,
          promoBadge = promoBadge,
          style = style,
          elapsedSec = elapsedSec,
          totalDurationSec = durationSec.toFloat(),
        )
        frameBitmap.getPixels(argbPixels, 0, width, 0, 0, width, height)
        encodeArgbToYuv420(argbPixels, width, height, yuvBytes, isSemiPlanar)

        var queued = false
        while (!queued) {
          val inIndex = encoder.dequeueInputBuffer(10_000L)
          if (inIndex >= 0) {
            val inputBuffer = encoder.getInputBuffer(inIndex)
            inputBuffer?.clear()
            inputBuffer?.put(yuvBytes, 0, min(yuvBytes.size, inputBuffer.capacity()))
            encoder.queueInputBuffer(inIndex, 0, yuvBytes.size, frameIdx * frameDurationUs, 0)
            queued = true
          }
          drainOutput(endOfStream = false)
        }

        if (frameIdx % 6 == 0 || frameIdx == totalFrames - 1) {
          onFrameProgress((frameIdx + 1).toFloat() / totalFrames.toFloat())
        }
      }

      // Send EOS
      var eosQueued = false
      while (!eosQueued) {
        val inIndex = encoder.dequeueInputBuffer(10_000L)
        if (inIndex >= 0) {
          encoder.queueInputBuffer(
            inIndex,
            0,
            0,
            totalFrames * frameDurationUs,
            MediaCodec.BUFFER_FLAG_END_OF_STREAM,
          )
          eosQueued = true
        }
        drainOutput(endOfStream = false)
      }
      drainOutput(endOfStream = true)

      if (muxerStarted) {
        muxer.stop()
      }
    } finally {
      runCatching { frameBitmap.recycle() }
      runCatching { encoder?.stop() }
      runCatching { encoder?.release() }
      runCatching { muxer?.release() }
    }
  }

  private fun selectYuvColorFormat(supported: IntArray): Int {
    val preferred =
      intArrayOf(
        MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar,
        MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar,
        MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible,
      )
    for (p in preferred) {
      if (supported.contains(p)) return p
    }
    return MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
  }

  private fun encodeArgbToYuv420(
    argb: IntArray,
    width: Int,
    height: Int,
    yuv420: ByteArray,
    semiPlanar: Boolean,
  ) {
    val frameSize = width * height
    var yIndex = 0
    var uvIndex = frameSize
    var uPlanarIndex = frameSize
    var vPlanarIndex = frameSize + frameSize / 4

    for (j in 0 until height) {
      for (i in 0 until width) {
        val pixel = argb[j * width + i]
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF

        val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
        yuv420[yIndex++] = y.coerceIn(0, 255).toByte()

        if ((j and 1) == 0 && (i and 1) == 0) {
          val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
          val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
          val cu = u.coerceIn(0, 255).toByte()
          val cv = v.coerceIn(0, 255).toByte()
          if (semiPlanar) {
            if (uvIndex + 1 < yuv420.size) {
              yuv420[uvIndex++] = cu
              yuv420[uvIndex++] = cv
            }
          } else {
            if (uPlanarIndex < yuv420.size && vPlanarIndex < yuv420.size) {
              yuv420[uPlanarIndex++] = cu
              yuv420[vPlanarIndex++] = cv
            }
          }
        }
      }
    }
  }

  private data class EncodedAudioTrack(
    val format: MediaFormat,
    val samples: List<Pair<ByteArray, MediaCodec.BufferInfo>>,
  )

  private data class WavData(
    val sampleRate: Int,
    val channels: Int,
    val pcmBytes: ByteArray,
  )

  private fun readWavPcm16(file: File): WavData? {
    val bytes = file.readBytes()
    if (bytes.size < 44) return null
    val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
    val riff = ByteArray(4).apply { buf.get(this) }.decodeToString()
    if (riff != "RIFF") return null
    buf.int // chunk size
    val wave = ByteArray(4).apply { buf.get(this) }.decodeToString()
    if (wave != "WAVE") return null

    var sampleRate = 22050
    var channels = 1
    var pcmData: ByteArray? = null

    while (buf.remaining() >= 8) {
      val chunkId = ByteArray(4).apply { buf.get(this) }.decodeToString()
      val chunkSize = buf.int.coerceAtLeast(0)
      if (chunkSize > buf.remaining()) break
      when (chunkId) {
        "fmt " -> {
          val start = buf.position()
          buf.short // audioFormat
          channels = buf.short.toInt().coerceIn(1, 2)
          sampleRate = buf.int.coerceIn(8000, 48000)
          buf.position(start + chunkSize)
        }
        "data" -> {
          pcmData = ByteArray(chunkSize)
          buf.get(pcmData)
          break
        }
        else -> {
          buf.position(buf.position() + chunkSize)
        }
      }
    }
    val data = pcmData ?: return null
    if (data.isEmpty()) return null
    return WavData(sampleRate = sampleRate, channels = channels, pcmBytes = data)
  }

  private fun encodeWavToAac(wavFile: File, maxDurationSec: Int): EncodedAudioTrack? {
    val wav = readWavPcm16(wavFile) ?: return null
    val bytesPerSec = wav.sampleRate * wav.channels * 2
    val maxPcmBytes = min(wav.pcmBytes.size, bytesPerSec * maxDurationSec)
    if (maxPcmBytes <= 0) return null

    val aacFormat =
      MediaFormat.createAudioFormat(
          MediaFormat.MIMETYPE_AUDIO_AAC,
          wav.sampleRate,
          wav.channels,
        )
        .apply {
          setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
          setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
          setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384)
        }

    var encoder: MediaCodec? = null
    val samples = mutableListOf<Pair<ByteArray, MediaCodec.BufferInfo>>()
    var outputFormat: MediaFormat? = null

    return try {
      encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
      encoder.configure(aacFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
      encoder.start()

      val bufferInfo = MediaCodec.BufferInfo()
      var offset = 0
      var eosSent = false
      var eosReceived = false
      var lastPtsUs = -1L

      while (!eosReceived) {
        if (!eosSent) {
          val inIdx = encoder.dequeueInputBuffer(5_000L)
          if (inIdx >= 0) {
            val inBuf = encoder.getInputBuffer(inIdx)
            if (inBuf != null) {
              inBuf.clear()
              if (offset < maxPcmBytes) {
                val chunk = min(inBuf.capacity(), maxPcmBytes - offset)
                inBuf.put(wav.pcmBytes, offset, chunk)
                val ptsUs = (offset.toLong() * 1_000_000L) / max(1, bytesPerSec)
                encoder.queueInputBuffer(inIdx, 0, chunk, ptsUs, 0)
                offset += chunk
              } else {
                val ptsUs = (offset.toLong() * 1_000_000L) / max(1, bytesPerSec)
                encoder.queueInputBuffer(inIdx, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                eosSent = true
              }
            }
          }
        }

        val outIdx = encoder.dequeueOutputBuffer(bufferInfo, 5_000L)
        when {
          outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
            outputFormat = encoder.outputFormat
          }
          outIdx >= 0 -> {
            val outBuf = encoder.getOutputBuffer(outIdx)
            if (outBuf != null && bufferInfo.size > 0 && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
              val copy = ByteArray(bufferInfo.size)
              outBuf.position(bufferInfo.offset)
              outBuf.get(copy)
              val safePts = max(bufferInfo.presentationTimeUs, lastPtsUs + 1L)
              lastPtsUs = safePts
              val copyInfo =
                MediaCodec.BufferInfo().apply {
                  set(0, copy.size, safePts, bufferInfo.flags)
                }
              samples.add(copy to copyInfo)
            }
            encoder.releaseOutputBuffer(outIdx, false)
            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
              eosReceived = true
            }
          }
        }
      }

      val fmt = outputFormat ?: return null
      if (samples.isEmpty()) return null
      EncodedAudioTrack(fmt, samples)
    } finally {
      runCatching { encoder?.stop() }
      runCatching { encoder?.release() }
    }
  }

  private fun writeEncodedAudio(
    muxer: MediaMuxer,
    trackIndex: Int,
    audioTrack: EncodedAudioTrack,
  ) {
    for ((bytes, info) in audioTrack.samples) {
      val buf = ByteBuffer.wrap(bytes)
      muxer.writeSampleData(trackIndex, buf, info)
    }
  }

  private fun saveVideoToMovies(sourceMp4: File): Pair<Uri, String> {
    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    val fileName = "AdFlowAI_$stamp.mp4"

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      val values =
        ContentValues().apply {
          put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
          put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
          put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AdFlowAI")
          put(MediaStore.Video.Media.IS_PENDING, 1)
        }
      val resolver = context.contentResolver
      val itemUri =
        resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
          ?: throw IllegalStateException("Falha ao criar arquivo em Movies/AdFlowAI")

      resolver.openOutputStream(itemUri)?.use { out ->
        FileInputStream(sourceMp4).use { input -> input.copyTo(out) }
      } ?: throw IllegalStateException("Falha ao gravar vídeo no MediaStore")

      values.clear()
      values.put(MediaStore.Video.Media.IS_PENDING, 0)
      resolver.update(itemUri, values, null, null)
      return itemUri to "Movies/AdFlowAI/$fileName"
    } else {
      @Suppress("DEPRECATION")
      val publicMovies =
        File(
          Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
          "AdFlowAI",
        )
      val targetDir =
        if (runCatching { publicMovies.mkdirs() || publicMovies.exists() }.getOrDefault(false) &&
          publicMovies.canWrite()
        ) {
          publicMovies
        } else {
          File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "AdFlowAI").apply {
            mkdirs()
          }
        }
      val destFile = File(targetDir, fileName)
      sourceMp4.copyTo(destFile, overwrite = true)

      runCatching {
        MediaScannerConnection.scanFile(
          context,
          arrayOf(destFile.absolutePath),
          arrayOf("video/mp4"),
          null,
        )
      }

      val uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", destFile)
      return uri to "Movies/AdFlowAI/$fileName"
    }
  }

  companion object {
    private const val FPS = 24
    private const val MAX_WIDTH_2K = 1440
    private const val MAX_HEIGHT_2K = 2560
  }
}
