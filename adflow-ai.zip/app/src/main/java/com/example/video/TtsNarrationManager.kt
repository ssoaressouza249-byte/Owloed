package com.example.video

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull

class TtsNarrationManager(context: Context) {

  private val appContext = context.applicationContext
  private var tts: TextToSpeech? = null
  private var isReady = false

  private suspend fun ensureInitialized(): Boolean =
    withTimeoutOrNull(4500L) {
      if (isReady && tts != null) return@withTimeoutOrNull true
      suspendCancellableCoroutine { cont ->
        runCatching {
            tts =
              TextToSpeech(appContext) { status ->
                val ok =
                  if (status == TextToSpeech.SUCCESS) {
                    runCatching {
                        val ptBr = Locale("pt", "BR")
                        val res = tts?.setLanguage(ptBr)
                        tts?.setSpeechRate(1.06f)
                        res != TextToSpeech.LANG_MISSING_DATA &&
                          res != TextToSpeech.LANG_NOT_SUPPORTED
                      }
                      .getOrDefault(false)
                  } else {
                    false
                  }
                isReady = ok || (status == TextToSpeech.SUCCESS)
                if (cont.isActive) cont.resume(isReady)
              }
          }
          .onFailure {
            isReady = false
            if (cont.isActive) cont.resume(false)
          }
      }
    } ?: false

  suspend fun speakLive(text: String) {
    if (text.isBlank()) return
    runCatching {
      val initialized = ensureInitialized()
      if (!initialized) return
      val utteranceId = UUID.randomUUID().toString()
      tts?.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), utteranceId)
    }
  }

  fun stopLive() {
    runCatching { tts?.stop() }
  }

  suspend fun synthesizeToWavFile(text: String, outputFile: File): File? {
    if (text.isBlank()) return null
    return runCatching {
        val initialized = ensureInitialized()
        if (!initialized) return null
        val engine = tts ?: return null

        withTimeoutOrNull(14000L) {
          suspendCancellableCoroutine<File?> { cont ->
            val utteranceId = "adflow_tts_${UUID.randomUUID()}"
            engine.setOnUtteranceProgressListener(
              object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}

                override fun onDone(id: String?) {
                  if (id == utteranceId && cont.isActive) {
                    val valid = outputFile.exists() && outputFile.length() > 44L
                    cont.resume(if (valid) outputFile else null)
                  }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) {
                  if (id == utteranceId && cont.isActive) {
                    cont.resume(null)
                  }
                }

                override fun onError(id: String?, errorCode: Int) {
                  if (id == utteranceId && cont.isActive) {
                    cont.resume(null)
                  }
                }
              }
            )

            val params = Bundle()
            val result = engine.synthesizeToFile(text, params, outputFile, utteranceId)
            if (result != TextToSpeech.SUCCESS && cont.isActive) {
              cont.resume(null)
            }
          }
        }
      }
      .getOrNull()
  }

  fun release() {
    runCatching {
      tts?.stop()
      tts?.shutdown()
      tts = null
      isReady = false
    }
  }
}
