package com.example.data

import com.example.model.AdScene
import com.example.model.ChatMessage
import com.example.model.MessageRole
import com.example.model.VideoScriptPayload
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class GeminiChatService {

  private val client: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .connectTimeout(25, TimeUnit.SECONDS)
      .readTimeout(60, TimeUnit.SECONDS)
      .writeTimeout(30, TimeUnit.SECONDS)
      .build()
  }

  suspend fun sendMessage(
    apiKey: String,
    model: String,
    history: List<ChatMessage>,
    userPrompt: String,
  ): Result<Pair<String, VideoScriptPayload?>> =
    withContext(Dispatchers.IO) {
      runCatching {
        val cleanKey = apiKey.trim()
        require(cleanKey.isNotEmpty()) {
          "Configure sua chave da API do Gemini acima para iniciar."
        }
        val cleanModel = model.trim().ifBlank { GeminiPrefsRepository.DEFAULT_MODEL }

        val contentsArray = JSONArray()
        val recentHistory = history.filter { !it.isError }.takeLast(10)
        for (msg in recentHistory) {
          val roleStr = if (msg.role == MessageRole.USER) "user" else "model"
          val partObj = JSONObject().put("text", msg.text)
          contentsArray.put(
            JSONObject().put("role", roleStr).put("parts", JSONArray().put(partObj))
          )
        }
        contentsArray.put(
          JSONObject()
            .put("role", "user")
            .put("parts", JSONArray().put(JSONObject().put("text", userPrompt)))
        )

        val requestPayload =
          JSONObject().apply {
            put(
              "systemInstruction",
              JSONObject()
                .put(
                  "parts",
                  JSONArray().put(JSONObject().put("text", SYSTEM_INSTRUCTION_PT_BR)),
                ),
            )
            put("contents", contentsArray)
            put(
              "generationConfig",
              JSONObject().apply {
                put("temperature", 0.75)
                put("maxOutputTokens", 1400)
              },
            )
          }

        val url =
          "https://generativelanguage.googleapis.com/v1beta/models/$cleanModel:generateContent?key=$cleanKey"
        val body =
          requestPayload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder().url(url).post(body).build()
        client.newCall(request).execute().use { response ->
          val responseBody = response.body?.string().orEmpty()
          if (!response.isSuccessful) {
            val apiError =
              runCatching {
                  JSONObject(responseBody).optJSONObject("error")?.optString("message").orEmpty()
                }
                .getOrDefault("")
            val hint =
              when (response.code) {
                400, 401, 403 ->
                  "Chave API inválida ou sem permissão para o modelo '$cleanModel'."
                404 -> "Modelo '$cleanModel' não encontrado. Tente alternar o modelo nas configurações."
                429 -> "Limite de requisições atingido. Aguarde alguns instantes e tente novamente."
                else -> "Erro HTTP ${response.code}"
              }
            val fullMsg = if (apiError.isNotBlank()) "$hint ($apiError)" else hint
            throw IllegalStateException(fullMsg)
          }

          val json = JSONObject(responseBody)
          val candidates = json.optJSONArray("candidates")
          val firstCandidate = candidates?.optJSONObject(0)
          val parts = firstCandidate?.optJSONObject("content")?.optJSONArray("parts")
          val replyText =
            buildString {
                if (parts != null) {
                  for (i in 0 until parts.length()) {
                    val t = parts.optJSONObject(i)?.optString("text").orEmpty()
                    if (t.isNotBlank()) {
                      if (isNotEmpty()) append("\n")
                      append(t)
                    }
                  }
                }
              }
              .trim()

          require(replyText.isNotEmpty()) {
            "A IA não retornou texto. Tente reformular sua pergunta."
          }

          val parsedScript = ScriptParser.parseIfMarketingScript(replyText, userPrompt)
          replyText to parsedScript
        }
      }
    }

  companion object {
    private const val SYSTEM_INSTRUCTION_PT_BR =
      """Você é o estrategista criativo e roteirista oficial do ADFLOW AI, especialista em marketing digital, copywriting persuasivo e vídeos curtos de alta conversão (Reels, TikTok, Shorts e WhatsApp Status).

Regras de comportamento:
1. Responda a QUALQUER pergunta do usuário com inteligência, clareza e foco prático em português do Brasil (PT-BR).
2. SEMPRE que o usuário pedir para divulgar, vender, anunciar ou criar um roteiro/vídeo para um produto, serviço, loja ou oferta, estruture o roteiro obrigatoriamente em cenas curtas (total máximo de 60 segundos) usando EXATAMENTE este formato de blocos para fácil leitura e conversão em vídeo:

TÍTULO: [Nome curto da campanha]
DURAÇÃO_SUGERIDA: [15s, 30s ou 60s]
SELO_OFERTA: [Texto curto de preço ou desconto, ex: 50% OFF ou R$ 99,90]

[GANCHO] (0s-5s): [Frase curta e impactante de abertura para prender atenção]
[OFERTA] (5s-20s): [Benefício principal + detalhe do produto/loja + prova/escassez]
[OFERTA] (20s-25s): [Condição especial ou bônus irresistível]
[CTA] (25s-30s): [Chamada para ação direta: link, WhatsApp ou loja física]

Mantenha cada legenda de cena objetiva (máximo 12 a 18 palavras por cena) para ficar legível em legendas grandes estilo Reels/TikTok."""
  }
}

object ScriptParser {

  private val marketingKeywords =
    listOf(
      "divulg",
      "anúnci",
      "anunci",
      "roteiro",
      "vend",
      "produt",
      "loja",
      "promo",
      "ofert",
      "descont",
      "vídeo",
      "video",
      "reels",
      "tiktok",
      "campanha",
      "gancho",
      "cta",
    )

  fun parseIfMarketingScript(aiText: String, userPrompt: String): VideoScriptPayload? {
    val lowerAi = aiText.lowercase()
    val lowerPrompt = userPrompt.lowercase()

    val hasExplicitTags =
      lowerAi.contains("[gancho]") ||
        lowerAi.contains("gancho:") ||
        lowerAi.contains("**gancho") ||
        (lowerAi.contains("oferta") && lowerAi.contains("cta"))

    val isMarketingIntent =
      hasExplicitTags || marketingKeywords.any { lowerPrompt.contains(it) || lowerAi.contains(it) }

    if (!isMarketingIntent) return null

    val scenes = mutableListOf<AdScene>()
    var title = "Campanha ADFLOW AI"
    var promoBadge = ""
    var suggestedDuration = 30

    val lines = aiText.lines().map { it.trim() }.filter { it.isNotEmpty() }

    for (rawLine in lines) {
      val cleanLine = rawLine.replace("**", "").replace("*", "").trim()
      val upper = cleanLine.uppercase()

      when {
        upper.startsWith("TÍTULO:") || upper.startsWith("TITULO:") -> {
          title = cleanLine.substringAfter(":").trim().ifBlank { title }
        }
        upper.startsWith("SELO_OFERTA:") || upper.startsWith("SELO:") || upper.startsWith("PREÇO:") -> {
          promoBadge = cleanLine.substringAfter(":").trim().take(28)
        }
        upper.startsWith("DURAÇÃO_SUGERIDA:") || upper.startsWith("DURACAO_SUGERIDA:") -> {
          val num = Regex("\\d+").find(cleanLine)?.value?.toIntOrNull()
          if (num != null) {
            suggestedDuration =
              when {
                num <= 20 -> 15
                num <= 45 -> 30
                else -> 60
              }
          }
        }
        upper.contains("GANCHO") && cleanLine.contains(":") -> {
          val caption = extractCaptionAfterColon(cleanLine)
          if (caption.isNotBlank()) scenes.add(AdScene(tag = "GANCHO", caption = caption))
        }
        upper.contains("OFERTA") && cleanLine.contains(":") -> {
          val caption = extractCaptionAfterColon(cleanLine)
          if (caption.isNotBlank()) scenes.add(AdScene(tag = "OFERTA", caption = caption))
        }
        (upper.contains("CTA") || upper.contains("CHAMADA PARA AÇÃO")) && cleanLine.contains(":") -> {
          val caption = extractCaptionAfterColon(cleanLine)
          if (caption.isNotBlank()) scenes.add(AdScene(tag = "CTA", caption = caption))
        }
        Regex("^\\[?CENA\\s*\\d+.*?:.*", RegexOption.IGNORE_CASE).matches(cleanLine) -> {
          val caption = extractCaptionAfterColon(cleanLine)
          if (caption.isNotBlank()) scenes.add(AdScene(tag = "CENA", caption = caption))
        }
      }
    }

    // Fallback: if marketing intent was detected but structured tags weren't matched, extract top sentences
    if (scenes.isEmpty()) {
      val fallbackLines =
        lines
          .filterNot { it.startsWith("#") || it.length < 10 }
          .map { it.replace("**", "").replace(Regex("^[-•\\d.)]+\\s*"), "").trim() }
          .filter { it.length in 10..140 }
          .take(4)

      if (fallbackLines.isEmpty()) return null
      fallbackLines.forEachIndexed { idx, text ->
        val tag =
          when (idx) {
            0 -> "GANCHO"
            fallbackLines.lastIndex -> "CTA"
            else -> "OFERTA"
          }
        scenes.add(AdScene(tag = tag, caption = text))
      }
    }

    if (promoBadge.isBlank()) {
      val priceMatch =
        Regex("R\\$\\s*\\d+[.,]?\\d*|\\d+%\\s*OFF", RegexOption.IGNORE_CASE).find(aiText)
      promoBadge = priceMatch?.value?.uppercase()?.take(24) ?: "OFERTA EXCLUSIVA"
    }

    val narration = scenes.joinToString(". ") { it.caption }
    return VideoScriptPayload(
      title = title,
      scenes = scenes,
      fullNarration = narration,
      suggestedPromoBadge = promoBadge,
      suggestedDurationSec = suggestedDuration.coerceAtMost(60),
    )
  }

  private fun extractCaptionAfterColon(line: String): String {
    val afterColon = line.substringAfter(":").trim()
    return afterColon
      .removePrefix("\"")
      .removeSuffix("\"")
      .replace(Regex("^\\(\\d+s?-\\d+s?\\)\\s*"), "")
      .trim()
  }
}
