package com.example.data

import android.content.Context
import android.content.SharedPreferences

class GeminiPrefsRepository(context: Context) {

  private val prefs: SharedPreferences =
    context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

  fun getApiKey(): String =
    runCatching { prefs.getString(KEY_GEMINI_API_KEY, "") ?: "" }.getOrDefault("")

  fun saveApiKey(apiKey: String) {
    runCatching { prefs.edit().putString(KEY_GEMINI_API_KEY, apiKey.trim()).apply() }
  }

  fun getSelectedModel(): String =
    runCatching {
        prefs.getString(KEY_GEMINI_MODEL, DEFAULT_MODEL)?.takeIf { it.isNotBlank() }
          ?: DEFAULT_MODEL
      }
      .getOrDefault(DEFAULT_MODEL)

  fun saveSelectedModel(model: String) {
    val sanitized = model.trim().ifBlank { DEFAULT_MODEL }
    runCatching { prefs.edit().putString(KEY_GEMINI_MODEL, sanitized).apply() }
  }

  companion object {
    private const val PREFS_NAME = "adflow_ai_prefs"
    private const val KEY_GEMINI_API_KEY = "gemini_api_key"
    private const val KEY_GEMINI_MODEL = "gemini_model"
    const val DEFAULT_MODEL = "gemini-4-hydrogen"

    val AVAILABLE_MODELS =
      listOf(
        "gemini-4-hydrogen",
        "gemini-2.5-flash",
        "gemini-2.5-pro",
        "gemini-2.0-flash",
      )
  }
}
