package com.example.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

data class SecurityCheckResult(
  val isValid: Boolean,
  val actualPackage: String,
  val actualAppName: String,
)

object SecurityGuard {
  const val EXPECTED_PACKAGE = "com.raylan.adflowai"
  const val EXPECTED_APP_NAME = "ADFLOW AI"

  /**
   * Verifies ONLY that the app name ("ADFLOW AI") and package name ("com.raylan.adflowai") match
   * their original values. Deliberately does NOT inspect signing certificates so GitHub Actions
   * debug builds work seamlessly.
   */
  fun verify(context: Context): SecurityCheckResult {
    return runCatching {
        val actualPackage = context.packageName.orEmpty()
        val stringResName = runCatching { context.getString(R.string.app_name) }.getOrDefault("")
        val manifestLabel =
          runCatching { context.applicationInfo.loadLabel(context.packageManager).toString() }
            .getOrDefault("")

        val packageMatches = actualPackage == EXPECTED_PACKAGE
        val nameMatches =
          stringResName == EXPECTED_APP_NAME &&
            (manifestLabel.isEmpty() || manifestLabel == EXPECTED_APP_NAME)

        SecurityCheckResult(
          isValid = packageMatches && nameMatches,
          actualPackage = actualPackage,
          actualAppName = manifestLabel.ifBlank { stringResName },
        )
      }
      .getOrElse {
        SecurityCheckResult(isValid = false, actualPackage = "unknown", actualAppName = "unknown")
      }
  }
}

@Composable
fun TamperLockScreen(result: SecurityCheckResult) {
  val context = LocalContext.current

  // Immovable screen: swallow all system back presses
  BackHandler(enabled = true) {}

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(Color(0xFF7F1D1D), Color(0xFFB91C1C), Color(0xFF450A0A))
          )
        )
        .safeDrawingPadding()
        .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier.fillMaxWidth(),
    ) {
      Icon(
        imageVector = Icons.Filled.Warning,
        contentDescription = null,
        tint = Color(0xFFFEE2E2),
        modifier = Modifier.size(72.dp),
      )
      Spacer(modifier = Modifier.height(20.dp))
      Text(
        text = stringResource(R.string.security_tamper_title),
        color = Color.White,
        fontSize = 22.sp,
        fontWeight = FontWeight.ExtraBold,
        fontFamily = FontFamily.Default,
        textAlign = TextAlign.Center,
      )
      Spacer(modifier = Modifier.height(14.dp))
      Text(
        text = stringResource(R.string.security_tamper_desc),
        color = Color(0xFFFECACA),
        style = MaterialTheme.typography.bodyLarge,
        textAlign = TextAlign.Center,
      )
      Spacer(modifier = Modifier.height(16.dp))
      Text(
        text = "App: ${result.actualAppName}\nPacote: ${result.actualPackage}",
        color = Color(0xFFFCA5A5),
        fontFamily = FontFamily.Monospace,
        fontSize = 12.sp,
        textAlign = TextAlign.Center,
      )
      Spacer(modifier = Modifier.height(32.dp))
      Button(
        onClick = {
          runCatching {
            val uninstallIntent =
              Intent(Intent.ACTION_DELETE).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
              }
            context.startActivity(uninstallIntent)
          }
        },
        colors =
          ButtonDefaults.buttonColors(
            containerColor = Color.White,
            contentColor = Color(0xFF991B1B),
          ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().height(56.dp).testTag("uninstall_now_button"),
      ) {
        Icon(imageVector = Icons.Filled.DeleteForever, contentDescription = null)
        Spacer(modifier = Modifier.size(8.dp))
        Text(
          text = stringResource(R.string.security_uninstall_now),
          fontWeight = FontWeight.ExtraBold,
          fontSize = 15.sp,
          fontFamily = FontFamily.Monospace,
        )
      }
    }
  }
}
