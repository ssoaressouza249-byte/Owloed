package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.MovieFilter
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.GeminiPrefsRepository
import com.example.model.ChatMessage
import com.example.model.MessageRole
import com.example.model.VideoScriptPayload
import com.example.ui.AdFlowUiState
import com.example.ui.components.CyberLuxuryCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ElectricPurpleBright
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGoldBright
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ChatScreen(
  state: AdFlowUiState,
  onToggleApiPanel: () -> Unit,
  onSaveApiConfig: (String, String) -> Unit,
  onSelectModel: (String) -> Unit,
  onSendMessage: (String) -> Unit,
  onTransformToVideo: (VideoScriptPayload) -> Unit,
  modifier: Modifier = Modifier,
) {
  var promptInput by rememberSaveable { mutableStateOf("") }
  val listState = rememberLazyListState()

  LaunchedEffect(state.chatMessages.size, state.isChatLoading) {
    if (state.chatMessages.isNotEmpty()) {
      listState.animateScrollToItem(state.chatMessages.lastIndex)
    }
  }

  Column(
    modifier = modifier.fillMaxSize().padding(horizontal = 14.dp),
  ) {
    // Collapsible Gemini API Key & Model Config Card
    ApiConfigCard(
      savedKey = state.apiKey,
      selectedModel = state.selectedModel,
      expanded = state.isApiPanelExpanded,
      savedFeedback = state.apiKeySavedFeedback,
      onToggleExpand = onToggleApiPanel,
      onSave = onSaveApiConfig,
      onSelectModel = onSelectModel,
    )

    Spacer(modifier = Modifier.height(8.dp))

    // Messages List
    LazyColumn(
      state = listState,
      modifier = Modifier.weight(1f).fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(10.dp),
      contentPadding = PaddingValues(vertical = 6.dp),
    ) {
      items(state.chatMessages, key = { it.id }) { msg ->
        ChatBubbleItem(
          message = msg,
          onTransformToVideo = onTransformToVideo,
        )
      }
      if (state.isChatLoading) {
        item(key = "loading_indicator") {
          Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              color = NeonGold,
              strokeWidth = 2.dp,
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "Roteirizando com ${state.selectedModel}...",
              style = MaterialTheme.typography.labelMedium,
              color = ElectricPurpleBright,
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Quick Campaign Prompts
    QuickPromptStrip(
      onPickPrompt = { suggestion ->
        promptInput = suggestion
      }
    )

    Spacer(modifier = Modifier.height(6.dp))

    // Chat Input Row
    Row(
      modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      OutlinedTextField(
        value = promptInput,
        onValueChange = { promptInput = it },
        placeholder = {
          Text(
            text = stringResource(R.string.chat_input_hint),
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
          )
        },
        maxLines = 4,
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
        keyboardActions =
          KeyboardActions(
            onSend = {
              if (promptInput.isNotBlank() && !state.isChatLoading) {
                onSendMessage(promptInput)
                promptInput = ""
              }
            }
          ),
        shape = RoundedCornerShape(16.dp),
        colors =
          OutlinedTextFieldDefaults.colors(
            focusedBorderColor = ElectricPurple,
            unfocusedBorderColor = BorderSubtle,
            focusedContainerColor = ObsidianCard,
            unfocusedContainerColor = ObsidianCard,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            cursorColor = NeonGold,
          ),
        modifier = Modifier.weight(1f).testTag("chat_prompt_input"),
      )

      Box(
        modifier =
          Modifier.size(52.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
              if (promptInput.isNotBlank() && !state.isChatLoading) {
                Brush.linearGradient(listOf(ElectricPurple, NeonGold))
              } else {
                Brush.linearGradient(listOf(ObsidianElevated, ObsidianElevated))
              }
            )
            .clickable(enabled = promptInput.isNotBlank() && !state.isChatLoading) {
              onSendMessage(promptInput)
              promptInput = ""
            }
            .testTag("chat_send_button"),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.Send,
          contentDescription = stringResource(R.string.chat_send_desc),
          tint = Color.White,
          modifier = Modifier.size(22.dp),
        )
      }
    }
  }
}

@Composable
private fun ApiConfigCard(
  savedKey: String,
  selectedModel: String,
  expanded: Boolean,
  savedFeedback: Boolean,
  onToggleExpand: () -> Unit,
  onSave: (String, String) -> Unit,
  onSelectModel: (String) -> Unit,
) {
  var keyDraft by remember(savedKey) { mutableStateOf(savedKey) }
  var modelDraft by remember(selectedModel) { mutableStateOf(selectedModel) }
  var showKey by rememberSaveable { mutableStateOf(false) }

  CyberLuxuryCard(
    borderBrush =
      Brush.horizontalGradient(
        listOf(ElectricPurple.copy(alpha = 0.85f), NeonGold.copy(alpha = 0.7f))
      ),
    cornerRadiusDp = 16,
  ) {
    Row(
      modifier =
        Modifier.fillMaxWidth()
          .minimumInteractiveComponentSize()
          .clickable(onClick = onToggleExpand)
          .testTag("api_config_toggle"),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        Icon(
          imageVector = Icons.Filled.Key,
          contentDescription = null,
          tint = if (savedKey.isNotBlank()) EmeraldSuccess else NeonGold,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
          Text(
            text = stringResource(R.string.api_config_title),
            style = MaterialTheme.typography.titleMedium,
            fontSize = 14.sp,
            color = TextPrimary,
          )
          Text(
            text =
              if (savedKey.isNotBlank()) {
                "${stringResource(R.string.api_status_ready)} • $selectedModel"
              } else {
                "${stringResource(R.string.api_status_missing)} • $selectedModel"
              },
            style = MaterialTheme.typography.labelSmall,
            color = if (savedKey.isNotBlank()) EmeraldSuccess else NeonGoldBright,
          )
        }
      }
      Icon(
        imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
        contentDescription = "Expandir ou recolher configuração da API",
        tint = TextSecondary,
      )
    }

    AnimatedVisibility(visible = expanded) {
      Column(modifier = Modifier.padding(top = 12.dp)) {
        OutlinedTextField(
          value = keyDraft,
          onValueChange = { keyDraft = it },
          label = { Text(stringResource(R.string.api_key_label)) },
          placeholder = { Text(stringResource(R.string.api_key_hint)) },
          singleLine = true,
          visualTransformation =
            if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
          trailingIcon = {
            IconButton(onClick = { showKey = !showKey }) {
              Icon(
                imageVector = if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                contentDescription = "Mostrar ou ocultar chave",
                tint = TextSecondary,
              )
            }
          },
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = NeonGold,
              unfocusedBorderColor = BorderSubtle,
              focusedLabelColor = NeonGoldBright,
              unfocusedLabelColor = TextSecondary,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary,
            ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth().testTag("gemini_api_key_input"),
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = stringResource(R.string.api_model_label),
          style = MaterialTheme.typography.labelMedium,
          color = TextSecondary,
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          GeminiPrefsRepository.AVAILABLE_MODELS.forEach { modelName ->
            val isSelected = modelDraft == modelName
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) ElectricPurple.copy(alpha = 0.28f) else ObsidianElevated,
              border =
                BorderStroke(
                  1.dp,
                  if (isSelected) ElectricPurpleBright else BorderSubtle,
                ),
              modifier =
                Modifier.minimumInteractiveComponentSize()
                  .clickable {
                    modelDraft = modelName
                    onSelectModel(modelName)
                  }
                  .testTag("model_chip_$modelName"),
            ) {
              Text(
                text = modelName,
                style = MaterialTheme.typography.labelSmall,
                color = if (isSelected) TextPrimary else TextSecondary,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = modelDraft,
          onValueChange = { modelDraft = it },
          label = { Text("Modelo customizado (padrão: gemini-4-hydrogen)") },
          singleLine = true,
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = ElectricPurple,
              unfocusedBorderColor = BorderSubtle,
              focusedLabelColor = ElectricPurpleBright,
              unfocusedLabelColor = TextSecondary,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary,
            ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth().testTag("gemini_model_input"),
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          if (savedFeedback) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Filled.CheckCircle,
                contentDescription = null,
                tint = EmeraldSuccess,
                modifier = Modifier.size(16.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Salvo localmente",
                style = MaterialTheme.typography.labelSmall,
                color = EmeraldSuccess,
              )
            }
          } else {
            Spacer(modifier = Modifier.width(1.dp))
          }

          Button(
            onClick = { onSave(keyDraft, modelDraft) },
            colors =
              ButtonDefaults.buttonColors(
                containerColor = ElectricPurple,
                contentColor = Color.White,
              ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.height(48.dp).testTag("save_api_key_button"),
          ) {
            Text(
              text = stringResource(R.string.api_save_button),
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ChatBubbleItem(
  message: ChatMessage,
  onTransformToVideo: (VideoScriptPayload) -> Unit,
) {
  val isUser = message.role == MessageRole.USER
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
  ) {
    val borderBrush =
      when {
        message.isError -> Brush.linearGradient(listOf(CyberCrimson, CyberCrimson))
        isUser -> Brush.linearGradient(listOf(ElectricPurple, ElectricPurpleBright))
        else ->
          Brush.linearGradient(
            listOf(ElectricPurple.copy(alpha = 0.7f), NeonGold.copy(alpha = 0.65f))
          )
      }

    val bubbleBg =
      when {
        message.isError -> Color(0x33EF4444)
        isUser -> Color(0x337C3AED)
        else -> ObsidianCard
      }

    Surface(
      shape =
        RoundedCornerShape(
          topStart = 18.dp,
          topEnd = 18.dp,
          bottomStart = if (isUser) 18.dp else 4.dp,
          bottomEnd = if (isUser) 4.dp else 18.dp,
        ),
      color = bubbleBg,
      border = BorderStroke(1.dp, borderBrush),
      modifier = Modifier.widthIn(max = 330.dp),
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        if (!isUser) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier =
                Modifier.size(18.dp)
                  .clip(CircleShape)
                  .background(Brush.linearGradient(listOf(ElectricPurple, NeonGold))),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Filled.AutoAwesome,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(11.dp),
              )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (message.isError) "AVISO DO SISTEMA" else "ADFLOW ROTEIRISTA IA",
              style = MaterialTheme.typography.labelSmall,
              color = if (message.isError) CyberCrimson else NeonGoldBright,
            )
          }
          Spacer(modifier = Modifier.height(6.dp))
        }

        Text(
          text = message.text.replace("**", ""),
          style = MaterialTheme.typography.bodyMedium,
          color = TextPrimary,
        )

        if (message.scriptPayload != null) {
          val payload = message.scriptPayload
          Spacer(modifier = Modifier.height(12.dp))
          Box(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF0A0C14))
                .border(1.dp, NeonGold.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                .padding(10.dp),
          ) {
            Column {
              Text(
                text =
                  "ROTEIRO PRONTO • ${payload.scenes.size} CENAS • ${payload.suggestedDurationSec}s",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                color = NeonGoldBright,
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Selo: ${payload.suggestedPromoBadge}",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricPurpleBright,
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Button(
            onClick = { onTransformToVideo(payload) },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = PaddingValues(0.dp),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("transform_to_video_button"),
          ) {
            Box(
              modifier =
                Modifier.fillMaxSize()
                  .clip(RoundedCornerShape(12.dp))
                  .background(Brush.horizontalGradient(listOf(ElectricPurple, NeonGold))),
              contentAlignment = Alignment.Center,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Filled.MovieFilter,
                  contentDescription = null,
                  tint = Color.White,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = stringResource(R.string.chat_transform_video),
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.ExtraBold,
                  fontSize = 12.sp,
                  color = Color.White,
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun QuickPromptStrip(onPickPrompt: (String) -> Unit) {
  val prompts =
    remember {
      listOf(
        "Crie um roteiro de 30s para divulgar minha loja de tênis com 40% OFF hoje",
        "Roteiro 15s oferta relâmpago para hamburgueria artesanal",
        "Roteiro luxo minimalista 60s para clínica de estética",
        "Quais os melhores ganchos para vender no Reels?",
      )
    }
  Row(
    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    prompts.forEachIndexed { index, text ->
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = ObsidianElevated,
        border = BorderStroke(1.dp, ElectricPurple.copy(alpha = 0.45f)),
        modifier =
          Modifier.clickable { onPickPrompt(text) }.testTag("quick_prompt_$index"),
      ) {
        Text(
          text = text,
          style = MaterialTheme.typography.labelSmall,
          color = ElectricPurpleBright,
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
        )
      }
    }
  }
}
