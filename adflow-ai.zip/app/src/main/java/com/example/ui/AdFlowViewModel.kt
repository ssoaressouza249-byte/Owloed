package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GeminiChatService
import com.example.data.GeminiPrefsRepository
import com.example.model.AdFlowTab
import com.example.model.AdScene
import com.example.model.ChatMessage
import com.example.model.ExportState
import com.example.model.MessageRole
import com.example.model.VideoDurationOption
import com.example.model.VideoQualityOption
import com.example.model.VideoScriptPayload
import com.example.model.VisualStyleOption
import com.example.video.AdVideoExporter
import com.example.video.TtsNarrationManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AdFlowUiState(
  val activeTab: AdFlowTab = AdFlowTab.CHAT_SCRIPT,
  // Tab 1: Chat & Gemini Config
  val apiKey: String = "",
  val selectedModel: String = GeminiPrefsRepository.DEFAULT_MODEL,
  val isApiPanelExpanded: Boolean = true,
  val apiKeySavedFeedback: Boolean = false,
  val chatMessages: List<ChatMessage> = defaultWelcomeMessages(),
  val isChatLoading: Boolean = false,
  // Tab 2: Video Studio
  val selectedPhotoUris: List<Uri> = emptyList(),
  val previewBitmaps: List<Bitmap> = emptyList(),
  val durationOption: VideoDurationOption = VideoDurationOption.SEC_30,
  val qualityOption: VideoQualityOption = VideoQualityOption.FHD_1080P,
  val visualStyle: VisualStyleOption = VisualStyleOption.NEON_GAMER,
  val promoBadge: String = "OFERTA HOJE",
  val scenes: List<AdScene> = defaultStudioScenes(),
  val narrationText: String =
    "Pare tudo e veja essa oportunidade exclusiva. Qualidade premium com condição especial por tempo limitado. Garanta o seu agora mesmo!",
  val ttsEnabled: Boolean = true,
  val isPreviewPlaying: Boolean = false,
  val previewElapsedSec: Float = 0f,
  val exportState: ExportState = ExportState.Idle,
)

private fun defaultWelcomeMessages(): List<ChatMessage> =
  listOf(
    ChatMessage(
      role = MessageRole.ASSISTANT,
      text =
        "Bem-vindo ao **ADFLOW AI**.\n\nSou seu estrategista de marketing e roteirista com foco em alta conversão. Configure sua chave da API do Gemini acima e peça um roteiro para seu produto ou loja — eu estruturo em **GANCHO**, **OFERTA** e **CTA** prontos para virar vídeo 9:16 em até 2K!",
    )
  )

private fun defaultStudioScenes(): List<AdScene> =
  listOf(
    AdScene(tag = "GANCHO", caption = "Pare de rolar! Você precisa ver essa novidade agora."),
    AdScene(tag = "OFERTA", caption = "Qualidade premium com condição especial por tempo limitado."),
    AdScene(tag = "CTA", caption = "Chame no WhatsApp ou clique no link e garanta o seu!"),
  )

class AdFlowViewModel(application: Application) : AndroidViewModel(application) {

  private val prefsRepo = GeminiPrefsRepository(application)
  private val chatService = GeminiChatService()
  private val ttsManager = TtsNarrationManager(application)
  private val videoExporter = AdVideoExporter(application, ttsManager)

  private val _uiState =
    MutableStateFlow(
      AdFlowUiState(
        apiKey = prefsRepo.getApiKey(),
        selectedModel = prefsRepo.getSelectedModel(),
        isApiPanelExpanded = prefsRepo.getApiKey().isBlank(),
      )
    )
  val uiState: StateFlow<AdFlowUiState> = _uiState.asStateFlow()

  private var previewJob: Job? = null
  private var exportJob: Job? = null

  fun selectTab(tab: AdFlowTab) {
    if (tab != AdFlowTab.VIDEO_STUDIO) {
      pausePreview()
    }
    _uiState.update { it.copy(activeTab = tab) }
  }

  fun toggleApiPanel() {
    _uiState.update { it.copy(isApiPanelExpanded = !it.isApiPanelExpanded, apiKeySavedFeedback = false) }
  }

  fun updateApiKeyAndModel(newKey: String, newModel: String) {
    val cleanKey = newKey.trim()
    val cleanModel = newModel.trim().ifBlank { GeminiPrefsRepository.DEFAULT_MODEL }
    prefsRepo.saveApiKey(cleanKey)
    prefsRepo.saveSelectedModel(cleanModel)
    _uiState.update {
      it.copy(
        apiKey = cleanKey,
        selectedModel = cleanModel,
        apiKeySavedFeedback = true,
        isApiPanelExpanded = cleanKey.isBlank(),
      )
    }
  }

  fun selectModel(model: String) {
    val cleanModel = model.trim().ifBlank { GeminiPrefsRepository.DEFAULT_MODEL }
    prefsRepo.saveSelectedModel(cleanModel)
    _uiState.update { it.copy(selectedModel = cleanModel) }
  }

  fun sendChatMessage(prompt: String) {
    val cleanPrompt = prompt.trim()
    if (cleanPrompt.isEmpty() || _uiState.value.isChatLoading) return

    val userMsg = ChatMessage(role = MessageRole.USER, text = cleanPrompt)
    val historySnapshot = _uiState.value.chatMessages

    _uiState.update {
      it.copy(
        chatMessages = it.chatMessages + userMsg,
        isChatLoading = true,
      )
    }

    viewModelScope.launch {
      val state = _uiState.value
      val result =
        chatService.sendMessage(
          apiKey = state.apiKey,
          model = state.selectedModel,
          history = historySnapshot,
          userPrompt = cleanPrompt,
        )

      result
        .onSuccess { (reply, parsedScript) ->
          val aiMsg =
            ChatMessage(
              role = MessageRole.ASSISTANT,
              text = reply,
              scriptPayload = parsedScript,
            )
          _uiState.update {
            it.copy(
              chatMessages = it.chatMessages + aiMsg,
              isChatLoading = false,
            )
          }
        }
        .onFailure { error ->
          val errMsg =
            ChatMessage(
              role = MessageRole.ASSISTANT,
              text = error.message ?: "Falha ao conectar com a API do Gemini.",
              isError = true,
            )
          _uiState.update {
            it.copy(
              chatMessages = it.chatMessages + errMsg,
              isChatLoading = false,
            )
          }
        }
    }
  }

  fun transformScriptToVideo(payload: VideoScriptPayload) {
    val matchedDuration =
      when {
        payload.suggestedDurationSec <= 20 -> VideoDurationOption.SEC_15
        payload.suggestedDurationSec <= 45 -> VideoDurationOption.SEC_30
        else -> VideoDurationOption.SEC_60
      }

    pausePreview()
    _uiState.update {
      it.copy(
        scenes = payload.scenes.ifEmpty { it.scenes },
        narrationText = payload.fullNarration.ifBlank { it.narrationText },
        promoBadge = payload.suggestedPromoBadge.ifBlank { it.promoBadge },
        durationOption = matchedDuration,
        previewElapsedSec = 0f,
        exportState = ExportState.Idle,
        activeTab = AdFlowTab.VIDEO_STUDIO,
      )
    }
    startPreview()
  }

  fun addPhotos(uris: List<Uri>) {
    if (uris.isEmpty()) return
    val merged = (_uiState.value.selectedPhotoUris + uris).distinct().take(10)
    _uiState.update { it.copy(selectedPhotoUris = merged) }
    reloadPreviewBitmaps(merged)
  }

  fun removePhoto(uri: Uri) {
    val updated = _uiState.value.selectedPhotoUris.filterNot { it == uri }
    _uiState.update { it.copy(selectedPhotoUris = updated) }
    reloadPreviewBitmaps(updated)
  }

  private fun reloadPreviewBitmaps(uris: List<Uri>) {
    viewModelScope.launch(Dispatchers.IO) {
      val context = getApplication<Application>()
      val decodedList = mutableListOf<Bitmap>()
      for (uri in uris) {
        runCatching {
          val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
          context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, boundsOpts)
          }
          val srcW = boundsOpts.outWidth.coerceAtLeast(1)
          val srcH = boundsOpts.outHeight.coerceAtLeast(1)
          var sample = 1
          while (srcW / sample > 720 || srcH / sample > 1280) {
            sample *= 2
          }
          val opts =
            BitmapFactory.Options().apply {
              inSampleSize = sample
              inPreferredConfig = Bitmap.Config.ARGB_8888
            }
          val bmp =
            context.contentResolver.openInputStream(uri)?.use { stream ->
              BitmapFactory.decodeStream(stream, null, opts)
            }
          if (bmp != null) decodedList.add(bmp)
        }
      }
      withContext(Dispatchers.Main) {
        _uiState.update { it.copy(previewBitmaps = decodedList) }
      }
    }
  }

  fun setDuration(option: VideoDurationOption) {
    _uiState.update {
      it.copy(
        durationOption = option,
        previewElapsedSec = it.previewElapsedSec.coerceAtMost(option.seconds.toFloat()),
      )
    }
  }

  fun setQuality(option: VideoQualityOption) {
    _uiState.update { it.copy(qualityOption = option) }
  }

  fun setVisualStyle(style: VisualStyleOption) {
    _uiState.update { it.copy(visualStyle = style) }
  }

  fun setPromoBadge(text: String) {
    _uiState.update { it.copy(promoBadge = text.take(30)) }
  }

  fun updateCaptionsFromText(rawText: String) {
    val lines =
      rawText
        .lines()
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .take(8)
    val updatedScenes =
      if (lines.isEmpty()) {
        emptyList()
      } else {
        lines.mapIndexed { idx, line ->
          val tag =
            when {
              idx == 0 -> "GANCHO"
              idx == lines.lastIndex && lines.size > 1 -> "CTA"
              else -> "OFERTA"
            }
          AdScene(tag = tag, caption = line)
        }
      }
    _uiState.update {
      it.copy(
        scenes = updatedScenes,
        narrationText = lines.joinToString(". "),
      )
    }
  }

  fun setTtsEnabled(enabled: Boolean) {
    if (!enabled) ttsManager.stopLive()
    _uiState.update { it.copy(ttsEnabled = enabled) }
  }

  fun scrubPreview(elapsedSec: Float) {
    val maxSec = _uiState.value.durationOption.seconds.toFloat()
    _uiState.update { it.copy(previewElapsedSec = elapsedSec.coerceIn(0f, maxSec)) }
  }

  fun togglePreviewPlayback() {
    if (_uiState.value.isPreviewPlaying) {
      pausePreview()
    } else {
      startPreview()
    }
  }

  private fun startPreview() {
    previewJob?.cancel()
    val state = _uiState.value
    val totalSec = state.durationOption.seconds.toFloat()
    val startFrom = if (state.previewElapsedSec >= totalSec - 0.1f) 0f else state.previewElapsedSec

    _uiState.update { it.copy(isPreviewPlaying = true, previewElapsedSec = startFrom) }

    if (state.ttsEnabled && state.narrationText.isNotBlank()) {
      viewModelScope.launch { ttsManager.speakLive(state.narrationText) }
    }

    previewJob =
      viewModelScope.launch {
        var lastTimeNs = System.nanoTime()
        while (isActive && _uiState.value.isPreviewPlaying) {
          delay(33L)
          val nowNs = System.nanoTime()
          val dt = ((nowNs - lastTimeNs) / 1_000_000_000f).coerceIn(0.01f, 0.2f)
          lastTimeNs = nowNs

          val curTotal = _uiState.value.durationOption.seconds.toFloat()
          val nextElapsed = _uiState.value.previewElapsedSec + dt
          if (nextElapsed >= curTotal) {
            _uiState.update { it.copy(previewElapsedSec = 0f) }
            if (_uiState.value.ttsEnabled && _uiState.value.narrationText.isNotBlank()) {
              ttsManager.speakLive(_uiState.value.narrationText)
            }
          } else {
            _uiState.update { it.copy(previewElapsedSec = nextElapsed) }
          }
        }
      }
  }

  fun pausePreview() {
    previewJob?.cancel()
    previewJob = null
    ttsManager.stopLive()
    _uiState.update { it.copy(isPreviewPlaying = false) }
  }

  fun exportVideoMp4() {
    if (_uiState.value.exportState is ExportState.Rendering) return
    pausePreview()

    val snapshot = _uiState.value
    _uiState.update {
      it.copy(
        exportState =
          ExportState.Rendering(
            progress = 0.02f,
            stageLabel = "Iniciando estúdio de renderização...",
            targetResolution = "${snapshot.qualityOption.width}×${snapshot.qualityOption.height}",
          )
      )
    }

    exportJob?.cancel()
    exportJob =
      viewModelScope.launch {
        val result =
          videoExporter.exportVideo(
            photoUris = snapshot.selectedPhotoUris,
            scenes = snapshot.scenes,
            narrationText = snapshot.narrationText,
            promoBadge = snapshot.promoBadge,
            durationSec = snapshot.durationOption.seconds,
            requestedQuality = snapshot.qualityOption,
            style = snapshot.visualStyle,
            enableTts = snapshot.ttsEnabled,
          ) { progress, stageLabel, resLabel ->
            _uiState.update {
              it.copy(
                exportState =
                  ExportState.Rendering(
                    progress = progress,
                    stageLabel = stageLabel,
                    targetResolution = resLabel,
                  )
              )
            }
          }

        result
          .onSuccess { output ->
            _uiState.update {
              it.copy(
                exportState =
                  ExportState.Success(
                    videoUri = output.uri,
                    displayPath = output.displayPath,
                    width = output.width,
                    height = output.height,
                    usedFallback1080p = output.usedFallback1080p,
                    hasAudioTrack = output.hasAudioTrack,
                  )
              )
            }
          }
          .onFailure { error ->
            _uiState.update {
              it.copy(
                exportState =
                  ExportState.Error(
                    error.message ?: "Erro inesperado ao renderizar o vídeo MP4."
                  )
              )
            }
          }
      }
  }

  fun dismissExportState() {
    if (_uiState.value.exportState !is ExportState.Rendering) {
      _uiState.update { it.copy(exportState = ExportState.Idle) }
    }
  }

  override fun onCleared() {
    super.onCleared()
    previewJob?.cancel()
    exportJob?.cancel()
    ttsManager.release()
  }
}
