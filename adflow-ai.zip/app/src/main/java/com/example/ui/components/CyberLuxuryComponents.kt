package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AdFlowTab
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ElectricPurpleBright
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGoldBright
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CyberLuxuryCard(
  modifier: Modifier = Modifier,
  borderBrush: Brush =
    Brush.linearGradient(listOf(ElectricPurple.copy(alpha = 0.75f), NeonGold.copy(alpha = 0.55f))),
  cornerRadiusDp: Int = 18,
  content: @Composable ColumnScope.() -> Unit,
) {
  val shape = RoundedCornerShape(cornerRadiusDp.dp)
  Surface(
    modifier = modifier.fillMaxWidth(),
    shape = shape,
    color = ObsidianCard,
    border = BorderStroke(1.dp, borderBrush),
  ) {
    Column(modifier = Modifier.padding(14.dp), content = content)
  }
}

@Composable
fun CyberHeaderBar(
  activeModel: String,
  hasApiKey: Boolean,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier =
          Modifier.size(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(
              Brush.linearGradient(listOf(ElectricPurple, NeonGold))
            ),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.AutoAwesome,
          contentDescription = null,
          tint = Color.White,
          modifier = Modifier.size(20.dp),
        )
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text(
          text = "ADFLOW AI",
          style = MaterialTheme.typography.titleMedium,
          color = TextPrimary,
          fontWeight = FontWeight.ExtraBold,
          letterSpacing = 1.sp,
        )
        Text(
          text = "ESTÚDIO CYBER-LUXO",
          style = MaterialTheme.typography.labelSmall,
          color = NeonGoldBright,
        )
      }
    }

    Surface(
      shape = RoundedCornerShape(20.dp),
      color = ObsidianElevated,
      border =
        BorderStroke(
          1.dp,
          if (hasApiKey) ElectricPurple.copy(alpha = 0.8f) else NeonGold.copy(alpha = 0.8f),
        ),
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(
          modifier =
            Modifier.size(7.dp)
              .clip(CircleShape)
              .background(if (hasApiKey) Color(0xFF10B981) else NeonGold)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = activeModel,
          style = MaterialTheme.typography.labelSmall,
          color = if (hasApiKey) ElectricPurpleBright else NeonGoldBright,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}

@Composable
fun CyberBottomBarWithCredits(
  activeTab: AdFlowTab,
  onSelectTab: (AdFlowTab) -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier =
      modifier
        .fillMaxWidth()
        .background(ObsidianBg.copy(alpha = 0.96f))
        .border(width = 1.dp, color = ElectricPurple.copy(alpha = 0.28f))
        .navigationBarsPadding(),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      CyberTabButton(
        selected = activeTab == AdFlowTab.CHAT_SCRIPT,
        label = stringResource(R.string.tab_chat_title),
        icon = Icons.Filled.ChatBubble,
        accentColor = ElectricPurple,
        testTag = "tab_chat_button",
        onClick = { onSelectTab(AdFlowTab.CHAT_SCRIPT) },
        modifier = Modifier.weight(1f),
      )
      CyberTabButton(
        selected = activeTab == AdFlowTab.VIDEO_STUDIO,
        label = stringResource(R.string.tab_studio_title),
        icon = Icons.Filled.MovieCreation,
        accentColor = NeonGold,
        testTag = "tab_studio_button",
        onClick = { onSelectTab(AdFlowTab.VIDEO_STUDIO) },
        modifier = Modifier.weight(1f),
      )
    }

    // Official Footer Credits
    Box(
      modifier =
        Modifier.fillMaxWidth()
          .background(Color(0xFF050609))
          .padding(horizontal = 16.dp, vertical = 5.dp),
      contentAlignment = Alignment.Center,
    ) {
      Text(
        text = stringResource(R.string.credits_footer),
        fontFamily = FontFamily.Monospace,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        color = NeonGoldBright.copy(alpha = 0.9f),
        letterSpacing = 0.5.sp,
      )
    }
  }
}

@Composable
private fun CyberTabButton(
  selected: Boolean,
  label: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  accentColor: Color,
  testTag: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val bgBrush =
    if (selected) {
      Brush.horizontalGradient(
        listOf(accentColor.copy(alpha = 0.28f), ObsidianElevated)
      )
    } else {
      Brush.horizontalGradient(listOf(ObsidianCard, ObsidianCard))
    }

  Box(
    modifier =
      modifier
        .minimumInteractiveComponentSize()
        .height(48.dp)
        .clip(RoundedCornerShape(14.dp))
        .background(bgBrush)
        .border(
          width = if (selected) 1.2.dp else 1.dp,
          color = if (selected) accentColor else Color(0xFF24283D),
          shape = RoundedCornerShape(14.dp),
        )
        .clickable(onClick = onClick)
        .testTag(testTag),
    contentAlignment = Alignment.Center,
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center,
      modifier = Modifier.padding(horizontal = 10.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = if (selected) accentColor else TextSecondary,
        modifier = Modifier.size(18.dp),
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        color = if (selected) TextPrimary else TextSecondary,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}
