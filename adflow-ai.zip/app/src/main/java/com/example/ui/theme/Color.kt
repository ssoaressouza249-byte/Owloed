package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF07080C)
val ObsidianSurface = Color(0xFF0F111A)
val ObsidianCard = Color(0xCC131624)
val ObsidianCardSolid = Color(0xFF131624)
val ObsidianElevated = Color(0xFF1A1E30)

val ElectricPurple = Color(0xFF7C3AED)
val ElectricPurpleBright = Color(0xFFA78BFA)
val ElectricPurpleDeep = Color(0xFF4C1D95)

val NeonGold = Color(0xFFF59E0B)
val NeonGoldBright = Color(0xFFFBBF24)
val NeonGoldSoft = Color(0xFFFDE68A)

val CyberCyan = Color(0xFF22D3EE)
val CyberCrimson = Color(0xFFEF4444)
val TamperRed = Color(0xFFB91C1C)
val EmeraldSuccess = Color(0xFF10B981)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val BorderSubtle = Color(0xFF262A3E)
