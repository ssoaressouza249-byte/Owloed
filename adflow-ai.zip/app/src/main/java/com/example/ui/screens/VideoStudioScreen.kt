package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.R
import com.example.model.ExportState
import com.example.model.VideoDurationOption
import com.example.model.VideoQualityOption
import com.example.model.VisualStyleOption
import com.example.ui.AdFlowUiState
import com.example.ui.components.CyberLuxuryCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.ElectricPurpleBright
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGoldBright
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.video.AdFrameRenderer

@Composable
fun VideoStudioScreen(
  state: AdFlowUiState,
  onAddPhotos: (List<Uri>) -> Unit,
  onRemovePhoto: (Uri) -> Unit,
  onSelectDuration: (VideoDurationOption) -> Unit,
  onSelectQuality: (VideoQualityOption) -> Unit,
  onSelectStyle: (VisualStyleOption) -> Unit,
  onUpdatePromoBadge: (String) -> Unit,
  onUpdateCaptionsText: (String) -> Unit,
  onToggleTts: (Boolean) -> Unit,
  onTogglePreview: () -> Unit,
  onScrubPreview: (Float) -> Unit,
  onExportMp4: () -> Unit,
  onDismissExport: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current

  val photoPickerLauncher =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 10)
    ) { uris ->
      if (uris.isNotEmpty()) {
        onAddPhotos(uris)
      }
    }

  val legacyStoragePermissionLauncher =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
      onExportMp4()
    }

  var captionsDraft by
    remember(state.scenes) {
      mutableStateOf(state.scenes.joinToString("\n") { it.caption })
    }

  Column(
    modifier =
      modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 14.dp, vertical = 8.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    // 1. Live 9:16 Animated Canvas Preview
    StudioPreviewMonitor(
      state = state,
      onTogglePreview = onTogglePreview,
      onScrubPreview = onScrubPreview,
    )

    // 2. Gallery Photo Selector
    CyberLuxuryCard {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "MÍDIA DO PRODUTO / LOJA",
            style = MaterialTheme.typography.titleSmall,
            color = NeonGoldBright,
          )
          Text(
            text = "${state.selectedPhotoUris.size} foto(s) selecionada(s) • Ken Burns automático",
            style = MaterialTheme.typography.bodyMedium,
            fontSize = 12.sp,
            color = TextSecondary,
          )
        }
        Button(
          onClick = {
            runCatching {
              photoPickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
              )
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.height(48.dp).testTag("pick_photos_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.AddPhotoAlternate,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = "Galeria", fontWeight = FontWeight.Bold)
        }
      }

      if (state.selectedPhotoUris.isNotEmpty()) {
        Spacer(modifier = Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          items(state.selectedPhotoUris, key = { it.toString() }) { uri ->
            Box(
              modifier =
                Modifier.size(width = 76.dp, height = 108.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .border(1.dp, ElectricPurple.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
            ) {
              AsyncImage(
                model = uri,
                contentDescription = "Foto selecionada do produto",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
              )
              Box(
                modifier =
                  Modifier.align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(Color(0xCC07080C))
                    .clickable { onRemovePhoto(uri) },
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = Icons.Filled.Close,
                  contentDescription = "Remover foto",
                  tint = Color.White,
                  modifier = Modifier.size(14.dp),
                )
              }
            }
          }
        }
      }
    }

    // 3. Quick Controls: Duration, Quality (max 2K), Style, Price Seal & TTS
    CyberLuxuryCard {
      // Duration
      SectionLabel(icon = Icons.Filled.Timer, label = "DURAÇÃO DO VÍDEO (MÁX 60s)")
      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        VideoDurationOption.entries.forEach { option ->
          val selected = state.durationOption == option
          CyberSelectableChip(
            label = option.label,
            selected = selected,
            accent = ElectricPurple,
            testTag = "duration_${option.seconds}s",
            onClick = { onSelectDuration(option) },
            modifier = Modifier.weight(1f),
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Quality (1080p or 2K Ultra capped)
      SectionLabel(
        icon = Icons.Filled.HighQuality,
        label = "QUALIDADE DE EXPORTAÇÃO (LIMITE MÁXIMO 2K)",
      )
      Spacer(modifier = Modifier.height(8.dp))
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        VideoQualityOption.entries.forEach { quality ->
          val selected = state.qualityOption == quality
          CyberSelectableChip(
            label = quality.fullLabel,
            selected = selected,
            accent = NeonGold,
            testTag = "quality_${quality.shortLabel}",
            onClick = { onSelectQuality(quality) },
            modifier = Modifier.fillMaxWidth(),
          )
        }
      }
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "Fallback automático seguro para 1080p caso o MediaCodec do aparelho não suporte 2K.",
        style = MaterialTheme.typography.labelSmall,
        color = TextSecondary,
      )

      Spacer(modifier = Modifier.height(14.dp))

      // Visual Style
      SectionLabel(icon = Icons.Filled.Style, label = "ESTILO VISUAL CYBER-LUXO")
      Spacer(modifier = Modifier.height(8.dp))
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        VisualStyleOption.entries.forEach { style ->
          val selected = state.visualStyle == style
          val accent =
            when (style) {
              VisualStyleOption.NEON_GAMER -> ElectricPurple
              VisualStyleOption.FLASH_OFFER -> NeonGold
              VisualStyleOption.MINIMAL_LUXURY -> NeonGoldBright
            }
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (selected) accent.copy(alpha = 0.2f) else ObsidianElevated,
            border = BorderStroke(1.dp, if (selected) accent else BorderSubtle),
            modifier =
              Modifier.fillMaxWidth()
                .minimumInteractiveComponentSize()
                .clickable { onSelectStyle(style) }
                .testTag("style_${style.name}"),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column {
                Text(
                  text = style.title,
                  style = MaterialTheme.typography.titleMedium,
                  fontSize = 14.sp,
                  color = TextPrimary,
                )
                Text(
                  text = style.subtitle,
                  style = MaterialTheme.typography.labelSmall,
                  color = TextSecondary,
                )
              }
              if (selected) {
                Icon(
                  imageVector = Icons.Filled.CheckCircle,
                  contentDescription = null,
                  tint = accent,
                  modifier = Modifier.size(20.dp),
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Promo Badge / Price
      OutlinedTextField(
        value = state.promoBadge,
        onValueChange = onUpdatePromoBadge,
        label = { Text("Preço / Selo Promocional Pulsante") },
        placeholder = { Text("Ex: 50% OFF ou R$ 149,90") },
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors =
          OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonGold,
            unfocusedBorderColor = BorderSubtle,
            focusedLabelColor = NeonGoldBright,
            unfocusedLabelColor = TextSecondary,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
          ),
        modifier = Modifier.fillMaxWidth().testTag("promo_badge_input"),
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Captions & Narration
      OutlinedTextField(
        value = captionsDraft,
        onValueChange = {
          captionsDraft = it
          onUpdateCaptionsText(it)
        },
        label = { Text("Legendas Sincronizadas & Narração (1 cena por linha)") },
        minLines = 3,
        maxLines = 6,
        shape = RoundedCornerShape(12.dp),
        colors =
          OutlinedTextFieldDefaults.colors(
            focusedBorderColor = ElectricPurple,
            unfocusedBorderColor = BorderSubtle,
            focusedLabelColor = ElectricPurpleBright,
            unfocusedLabelColor = TextSecondary,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
          ),
        modifier = Modifier.fillMaxWidth().testTag("studio_captions_input"),
      )

      Spacer(modifier = Modifier.height(12.dp))

      // Automatic PT-BR Voice Narration Toggle
      Row(
        modifier =
          Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ObsidianElevated)
            .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Icon(
            imageVector = Icons.Filled.RecordVoiceOver,
            contentDescription = null,
            tint = if (state.ttsEnabled) NeonGoldBright else TextSecondary,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "Narração Automática por Voz",
              style = MaterialTheme.typography.titleMedium,
              fontSize = 14.sp,
              color = TextPrimary,
            )
            Text(
              text = "TTS Nativo em Português (PT-BR)",
              style = MaterialTheme.typography.labelSmall,
              color = TextSecondary,
            )
          }
        }
        Switch(
          checked = state.ttsEnabled,
          onCheckedChange = onToggleTts,
          colors =
            SwitchDefaults.colors(
              checkedThumbColor = Color.White,
              checkedTrackColor = ElectricPurple,
            ),
          modifier = Modifier.testTag("tts_switch"),
        )
      }
    }

    // 4. Real MP4 Export Action & Progress / Share Card
    ExportSectionCard(
      exportState = state.exportState,
      qualityOption = state.qualityOption,
      onStartExport = {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
          val granted =
            ContextCompat.checkSelfPermission(
              context,
              Manifest.permission.WRITE_EXTERNAL_STORAGE,
            ) == PackageManager.PERMISSION_GRANTED
          if (granted) {
            onExportMp4()
          } else {
            legacyStoragePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
          }
        } else {
          onExportMp4()
        }
      },
      onDismiss = onDismissExport,
      context = context,
    )

    Spacer(modifier = Modifier.height(10.dp))
  }
}

@Composable
private fun StudioPreviewMonitor(
  state: AdFlowUiState,
  onTogglePreview: () -> Unit,
  onScrubPreview: (Float) -> Unit,
) {
  val totalSec = state.durationOption.seconds.toFloat()
  CyberLuxuryCard(
    borderBrush =
      Brush.linearGradient(
        listOf(ElectricPurple, NeonGold)
      ),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = "PREVIEW 9:16 EM TEMPO REAL",
        style = MaterialTheme.typography.titleSmall,
        color = ElectricPurpleBright,
      )
      Text(
        text = "${formatSeconds(state.previewElapsedSec)} / ${formatSeconds(totalSec)}",
        fontFamily = FontFamily.Monospace,
        fontSize = 11.5.sp,
        fontWeight = FontWeight.Bold,
        color = NeonGoldBright,
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    Box(
      modifier = Modifier.fillMaxWidth(),
      contentAlignment = Alignment.Center,
    ) {
      Box(
        modifier =
          Modifier.widthIn(max = 240.dp)
            .fillMaxWidth()
            .aspectRatio(9f / 16f)
            .clip(RoundedCornerShape(18.dp))
            .background(ObsidianBg)
            .border(
              width = 1.5.dp,
              brush = Brush.linearGradient(listOf(ElectricPurple, NeonGold)),
              shape = RoundedCornerShape(18.dp),
            )
            .clickable(onClick = onTogglePreview)
            .testTag("studio_preview_canvas"),
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          AdFrameRenderer.drawFrame(
            canvas = drawContext.canvas.nativeCanvas,
            width = size.width.toInt().coerceAtLeast(1),
            height = size.height.toInt().coerceAtLeast(1),
            photos = state.previewBitmaps,
            scenes = state.scenes,
            promoBadge = state.promoBadge,
            style = state.visualStyle,
            elapsedSec = state.previewElapsedSec,
            totalDurationSec = totalSec,
          )
        }

        // Play / Pause subtle floating control
        Box(
          modifier =
            Modifier.align(Alignment.TopEnd)
              .padding(10.dp)
              .size(40.dp)
              .clip(CircleShape)
              .background(Color(0xAA07080C))
              .border(1.dp, NeonGold.copy(alpha = 0.7f), CircleShape),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = if (state.isPreviewPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
            contentDescription = if (state.isPreviewPlaying) "Pausar preview" else "Reproduzir preview",
            tint = Color.White,
            modifier = Modifier.size(22.dp),
          )
        }

        if (state.selectedPhotoUris.isEmpty()) {
          Box(
            modifier =
              Modifier.align(Alignment.Center)
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x9907080C))
                .padding(horizontal = 12.dp, vertical = 8.dp),
          ) {
            Text(
              text = "Adicione fotos na Galeria abaixo",
              style = MaterialTheme.typography.labelSmall,
              color = TextPrimary,
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(
        onClick = onTogglePreview,
        modifier = Modifier.testTag("preview_play_pause_button"),
      ) {
        Icon(
          imageVector = if (state.isPreviewPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
          contentDescription = "Alternar reprodução",
          tint = NeonGoldBright,
        )
      }
      Slider(
        value = state.previewElapsedSec.coerceIn(0f, totalSec),
        onValueChange = onScrubPreview,
        valueRange = 0f..totalSec,
        colors =
          SliderDefaults.colors(
            thumbColor = NeonGold,
            activeTrackColor = ElectricPurple,
            inactiveTrackColor = BorderSubtle,
          ),
        modifier = Modifier.weight(1f),
      )
    }
  }
}

@Composable
private fun ExportSectionCard(
  exportState: ExportState,
  qualityOption: VideoQualityOption,
  onStartExport: () -> Unit,
  onDismiss: () -> Unit,
  context: Context,
) {
  CyberLuxuryCard(
    borderBrush = Brush.horizontalGradient(listOf(NeonGold, ElectricPurple)),
  ) {
    when (exportState) {
      is ExportState.Idle -> {
        Text(
          text = "RENDERIZAÇÃO .MP4 REAL",
          style = MaterialTheme.typography.titleSmall,
          color = NeonGoldBright,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text =
            "Salva em Movies/AdFlowAI na resolução ${qualityOption.fullLabel} via MediaCodec + MediaMuxer.",
          style = MaterialTheme.typography.bodyMedium,
          fontSize = 12.5.sp,
          color = TextSecondary,
        )
        Spacer(modifier = Modifier.height(12.dp))
        Button(
          onClick = onStartExport,
          colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
          contentPadding = PaddingValues(0.dp),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().height(54.dp).testTag("export_mp4_button"),
        ) {
          Box(
            modifier =
              Modifier.fillMaxSize()
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.horizontalGradient(listOf(ElectricPurple, NeonGold))),
            contentAlignment = Alignment.Center,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Filled.MovieCreation,
                contentDescription = null,
                tint = Color.White,
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = stringResource(R.string.studio_export_mp4),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp,
                color = Color.White,
              )
            }
          }
        }
      }

      is ExportState.Rendering -> {
        val pct = (exportState.progress * 100).toInt().coerceIn(0, 100)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = exportState.stageLabel,
            style = MaterialTheme.typography.titleMedium,
            fontSize = 14.sp,
            color = TextPrimary,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = "$pct% • ${exportState.targetResolution}",
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = NeonGoldBright,
          )
        }
        Spacer(modifier = Modifier.height(10.dp))
        LinearProgressIndicator(
          progress = { exportState.progress.coerceIn(0f, 1f) },
          color = NeonGold,
          trackColor = ObsidianElevated,
          modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(6.dp)),
        )
      }

      is ExportState.Success -> {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Filled.CheckCircle,
            contentDescription = null,
            tint = EmeraldSuccess,
            modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "VÍDEO EXPORTADO COM SUCESSO!",
            style = MaterialTheme.typography.titleSmall,
            color = EmeraldSuccess,
          )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text =
            "Salvo em: ${exportState.displayPath}\nResolução: ${exportState.width}×${exportState.height}" +
              (if (exportState.hasAudioTrack) " • Com Áudio PT-BR" else " • Vídeo MP4"),
          style = MaterialTheme.typography.bodyMedium,
          fontSize = 12.5.sp,
          color = TextPrimary,
        )
        if (exportState.usedFallback1080p) {
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text =
              "Aviso: O hardware MediaCodec deste aparelho não suportou 2K; fallback seguro para 1080p aplicado automaticamente.",
            style = MaterialTheme.typography.labelSmall,
            color = NeonGoldBright,
          )
        }
        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Button(
            onClick = { shareVideoToTarget(context, exportState.videoUri, listOf("com.whatsapp", "com.whatsapp.w4b")) },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f).height(48.dp).testTag("share_whatsapp_button"),
          ) {
            Text(
              text = stringResource(R.string.studio_share_whatsapp),
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              maxLines = 1,
            )
          }
          Button(
            onClick = { shareVideoToTarget(context, exportState.videoUri, listOf("com.instagram.android")) },
            colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f).height(48.dp).testTag("share_instagram_button"),
          ) {
            Text(
              text = stringResource(R.string.studio_share_instagram),
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              maxLines = 1,
            )
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedButton(
            onClick = { shareVideoToTarget(context, exportState.videoUri, emptyList()) },
            border = BorderStroke(1.dp, NeonGold),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f).height(48.dp),
          ) {
            Icon(Icons.Filled.Share, contentDescription = null, tint = NeonGoldBright, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(stringResource(R.string.studio_share_more), color = NeonGoldBright, fontSize = 12.sp)
          }
          OutlinedButton(
            onClick = onDismiss,
            border = BorderStroke(1.dp, BorderSubtle),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f).height(48.dp),
          ) {
            Text("Novo Render", color = TextSecondary, fontSize = 12.sp)
          }
        }
      }

      is ExportState.Error -> {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Filled.ErrorOutline,
            contentDescription = null,
            tint = CyberCrimson,
            modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "FALHA NA EXPORTAÇÃO",
            style = MaterialTheme.typography.titleSmall,
            color = CyberCrimson,
          )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = exportState.message,
          style = MaterialTheme.typography.bodyMedium,
          color = TextPrimary,
        )
        Spacer(modifier = Modifier.height(10.dp))
        Button(
          onClick = onStartExport,
          colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth().height(48.dp),
        ) {
          Text("Tentar Novamente", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
private fun SectionLabel(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = CyberCyan,
      modifier = Modifier.size(16.dp),
    )
    Spacer(modifier = Modifier.width(6.dp))
    Text(
      text = label,
      style = MaterialTheme.typography.titleSmall,
      color = TextPrimary,
    )
  }
}

@Composable
private fun CyberSelectableChip(
  label: String,
  selected: Boolean,
  accent: Color,
  testTag: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = if (selected) accent.copy(alpha = 0.24f) else ObsidianElevated,
    border = BorderStroke(1.dp, if (selected) accent else BorderSubtle),
    modifier =
      modifier
        .minimumInteractiveComponentSize()
        .height(48.dp)
        .clickable(onClick = onClick)
        .testTag(testTag),
  ) {
    Box(
      contentAlignment = Alignment.Center,
      modifier = Modifier.padding(horizontal = 10.dp),
    ) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        color = if (selected) TextPrimary else TextSecondary,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

private fun formatSeconds(sec: Float): String {
  val total = sec.toInt().coerceAtLeast(0)
  val m = total / 60
  val s = total % 60
  return "%02d:%02d".format(m, s)
}

private fun shareVideoToTarget(
  context: Context,
  videoUri: Uri,
  preferredPackages: List<String>,
) {
  runCatching {
    val baseIntent =
      Intent(Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(Intent.EXTRA_STREAM, videoUri)
        putExtra(Intent.EXTRA_TEXT, "Criado com ADFLOW AI")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }

    for (pkg in preferredPackages) {
      val targeted = Intent(baseIntent).setPackage(pkg)
      val resolved = targeted.resolveActivity(context.packageManager)
      if (resolved != null) {
        context.startActivity(targeted)
        return
      }
    }

    context.startActivity(Intent.createChooser(baseIntent, "Compartilhar vídeo ADFLOW AI"))
  }
}
