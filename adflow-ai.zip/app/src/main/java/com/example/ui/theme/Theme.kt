package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AdFlowDarkColorScheme =
  darkColorScheme(
    primary = ElectricPurple,
    onPrimary = Color.White,
    primaryContainer = ElectricPurpleDeep,
    onPrimaryContainer = TextPrimary,
    secondary = NeonGold,
    onSecondary = Color(0xFF1A1000),
    secondaryContainer = Color(0xFF3D2700),
    onSecondaryContainer = NeonGoldSoft,
    tertiary = CyberCyan,
    onTertiary = Color(0xFF001F24),
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = ObsidianSurface,
    onSurface = TextPrimary,
    surfaceVariant = ObsidianElevated,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    error = CyberCrimson,
    onError = Color.White,
  )

@Composable
fun AdFlowTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = AdFlowDarkColorScheme,
    typography = AdFlowTypography,
    content = content,
  )
}
